---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Selong-Selo/Content/Selo-Content-Plan-2026-09-14-27-DRAFT.md
mtime: 2026-09-05 19:04:07 WITA
brand: Selong-Selo
title: Selo Content Plan 2026 09 14 27 DRAFT
date_range: 2026-09-14 to 2026-09-27
exported: 2026-09-14
---

# Selo fortnight draft · 14–27 Sep 2026 · honesty pass

Status: DRAFT. Source HTML selong-selo-2026-09-14-27. Handle @selo.properties. Foreign buyer. Nothing posted.
LEARN HTML used Mon/Wed/Fri — locked cadence is Tue/Thu/Sat. Remapped below.
CTA selogroup.co / DM SELO. No invented prices. No villa counts. No stay CTA. No availability invent.

## Tue 15 MATCH
Questions every Selong Belanak buyer is asking. Copy carousel. Annalise photo OK if we have one; talking-head = FILM.
1 hook "questions at selong belanak"
2 "can i legally buy"
3 "nominee · or a pt pma"
4 CTA "selogroup.co"
Answers in caption. No nominee tip.

## Thu 17 MATCH
Listings format. Categories only. No prices. No counts.
1 hook "what’s currently available"
2 "suite · land · villa"
3 CTA "DM SELO · selogroup.co"

## Sat 19 FILM
Reasons not to buy a Selong Selo villa. Host/graphic required. Do not schedule until shot or flipped to copy-only.

## Tue 22 FILM
If I was buying my first villa in South Lombok — Annalise or founder. On-camera allowed. Do not schedule until shot.

## Thu 24 FILM
POV you just bought a Selo Suite. Guests/pool/payout = FILM. Suite stills alone are not this post. No stay CTA.

## Sat 26 FILM
Walk around Serangan Indah with Annalise. Annalise 0 / Serangan 0 in prior catalogue. Do not schedule until shot.
