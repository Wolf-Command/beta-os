---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Selong-Selo/Content/Selo-Content-Plan-2026-08-24-30-DRAFT.md
mtime: 2026-08-17 20:51:58 WITA
brand: Selong-Selo
title: Selo Content Plan 2026 08 24 30 DRAFT
date_range: 2026-08-24 to 2026-08-30
exported: 2026-09-14
---

# Selo week 2 draft · 24–30 Aug 2026 · honesty pass

Status: DRAFT. Handle @selo.properties. Foreign buyer. Nothing posted.
CTA selogroup.co / DM SELO. No invented prices. No villa counts. No stay CTA.

## Tue 25 MATCH
Ask the right questions. Copy carousel. No talent required.
1 hook "ask the right questions"
2 "who manages it"
3 "who fills the nights"
4 CTA "selogroup.co"

## Thu 27 FILM
Annalise on Serangan Indah. On-camera allowed. Land stills alone are not this post. Do not schedule until she is shot.

## Sat 29 MATCH
Come back whenever — ownership, not a hotel stay.
1 suite still "yours to come back to"
2 CTA "selogroup.co"
Owner-arriving reel = FILM.
