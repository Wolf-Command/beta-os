---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Selong-Selo/Selong-Brand.md
mtime: 2026-06-23 19:45:38 WITA
brand: Selong-Selo
title: Selong Brand
date_range: n/a
exported: 2026-09-14
---

# Selong Selo — Complete Brand Knowledge

**Client:** GGV (Goss Group Ventures)  
**Brand Portfolio:** Selo Group (Selo Suites + Selong Selo Villa & Resorts sub-brands)  
**Brand Type:** Elevated luxury resort / destination  
**Location:** South Lombok (Selong / Selo area)  
**Status:** COMPLETE (text_style with logo override, full palette with sub-palettes)  
**Last Updated:** 2026-06-22 (from brand-config.json)

## Related Files

- [[Selong-Strategy|01-Wolf-Command/Brands/Selong-Selo/Selong-Strategy.md]]
- [[GGV-Brand|01-Wolf-Command/Brands/GGV/GGV-Brand.md]]
- [[Theme-Bank-Master|01-Wolf-Command/Atlas-System/Theme-Bank/Theme-Bank-Master.md]]
- [[Style-Profiles|01-Wolf-Command/Team/Content-Team/Style-Profiles.md]]


---

## ESSENCE & VOICE

**Brand Essence:** Elevated calm, aspirational, sophisticated resort  
**Voice Descriptors:**
- elevated calm
- aspirational
- sophisticated resort
- elevated & sophisticated
- calm restraint = luxury
- trustworthy, confidence over hype
- destination desire before ownership
- Aviano-caps + hairline-rule design

**Tone:** Sophisticated, restrained, confident. Calm restraint IS the luxury statement. No FOMO, no urgency — timeless positioning.

---

## COLOR PALETTE

**Main Palette (Selo Properties):**

| Role | Hex | Name | Usage |
|------|-----|------|-------|
| Sand | `#B3A79E` | Warm sand | Primary neutral |
| Green | `#788170` | Muted green | Primary accent, nature |
| Soft Yellow | `#E6D6B5` | Pale gold | Warmth, highlight |
| Light Beige | `#EBE4DC` | Off-white | Background, breathing |
| Dark Gray | `#272A26` | Charcoal | Depth, text |

**Sub-Palettes (Brand Family):**

**Selo Suites:**
- Matte Gold: `#AB9472`
- Charcoal: `#2B2E2E`
- Cool Grey: `#C4CFD5`

**Selong Selo Villa & Resorts:**
- Teal (dark): `#277182`
- Teal (mid): `#548C92`
- Teal (light): `#B4D7D8`
- Mist: `#E0D7CF`

**Bottom Bar:** `#788170` (muted green) at 0.7 opacity  
**Label Color:** `#EBE4DC` (off-white text — light on green)

---

## TYPOGRAPHY

**Primary Typeface:** Aviano Sans (geometric, elegant)  
**Secondary:** Gotham (modern, bookish)  
**Font Package:** `fonts/` (Aviano Sans + Gotham .otf installed)

| Role | Family | Weight | File | Usage |
|------|--------|--------|------|-------|
| Display (graphics) | Aviano Sans | Regular | AvianoSansRegular.otf | Headlines, branding |
| Sans (graphics) | Gotham | Book | GothamBook.otf | Body, secondary text |
| Accent | Alegreya | — | — | Decorative, quoted text |
| (Captions use palette heuristic) | — | — | — | — |

**Text Style (Logo-Only Config):**
- Primary logo asset: `logos/Selo_Properties_logo.png` (color) + `logos/Selo_Properties_logo_white.png` (white)
- No explicit role→color mapping; colors derive via palette luminance heuristic
- Logo placement: Top-left, 20% frame width, 5% margin

---

## LOGOS

**Asset Root:** `/Volumes/01-Media-Library/Brand-Assets/GGV/Selo`

| Logo | Path | Usage |
|------|------|-------|
| Primary Logo | `logos/Selo_Properties_logo.png` | Main lockup (color) |
| Primary Logo (white) | `logos/Selo_Properties_logo_white.png` | On dark backgrounds |

---

## VISUAL LANGUAGE

- Minimalist design language (hairline rules, negative space)
- Architecture + landscape photography (clean framing)
- Serene, uncluttered spaces
- Sophisticated color grading (not over-saturated)
- Lifestyle moments (quiet, reflective, authentic)
- Confident positioning (never desperate for bookings)
- Design-literate aesthetic (architecture, interior design focus)

---

## CONTENT PILLARS

1. **Sophisticated Design** — Architecture + interiors first
2. **Destination Positioning** — Location beauty + cultural context
3. **Calm Luxury** — Restraint over ostentation
4. **Ownership Confidence** — Managed-investment credibility
5. **Exclusivity & Trust** — Not for everyone (intentional positioning)

---

## VIDEO GRADING & MUSIC

**Reel Engine Slug:** `selong_selo`  
**Grading:** Cool, sophisticated, with subtle blue lift
- Master curve: `0/0 0.07/0.05 0.5/0.51 0.85/0.88 1/1`
- Red channel: Neutral, slight cool lift
- Blue channel: Enhanced cool tones
- Saturation: +8%, Contrast: +5%

**Music:** `soft-lounge-background.mp3` (refined, understated)  
**Pacing:** Medium-slow (allows for design appreciation)

**Reel Engine Codes (for auto-matching):**
- selo
- selong_selo
- selong selo
- selong
- ss

---

## AUDIENCE & POSITIONING

**Primary Audience:**
- Design-forward travelers (architects, designers, luxury travel enthusiasts)
- Managed investment community (financial professionals)
- Wellness + retreat audience (secondary)

**Messaging:**
- 50% architecture + design excellence
- 30% destination positioning (South Lombok)
- 20% managed-investment confidence

**Content Frequency:** Max 3x/week (quality over quantity; audience fatigue from overposting)

---

## CONTENT PERFORMANCE

**Best Platforms:**
- Instagram Feed (design community prefers slow scroll)
- Pinterest (design + luxury communities)
- Architecture/design blogs (editorial features)
- LinkedIn (investor community)

**Best Times:**
- Tue/Wed 10am–2pm WITA (professional audience, work breaks)
- Evening (leisure browsing)

**Highest Engagement Content:**
- Architecture + design deep-dives (6-8% ER)
- Minimal lifestyle moments (5-7% ER)
- Destination guides (6-8% ER)
- Investment updates (7-9% ER to investor segment)

---

## NAS & ASSET LOCATION

**NAS Path:** `/Volumes/01-Media-Library/Brand-Assets/GGV/Selo`

**Folder Structure:**
```
Selo/
├── fonts/ (Aviano Sans + Gotham)
├── logos/
│   ├── Selo_Properties_logo.png
│   └── Selo_Properties_logo_white.png
├── raws/ (footage)
├── finished/ (videos, photos)
└── graphics/ (promotional assets)
```

---

## APPROVAL & TEAM

**Content Lead (Reviewer):** Nindy (GGV)  
**Editor:** Haikal (GGV)  
**Director:** Mr Wolf, Amanda (GGV GM)

**Style Profile:** See `/01-Wolf-Command/Team/Content-Team/Style-Profiles.md` (Nindy, Haikal)

---

## BRAND CONFIG STATUS

**Text Style:** COMPLETE (logo-only, full palette with sub-palettes configured)  
**Logo Paths:** COMPLETE (primary + white variants)  
**Fonts:** COMPLETE (Aviano Sans + Gotham installed)  
**Intro/Outro:** Standard (default outro enabled)  
**Reel Engine:** MIGRATED (grading + music verified 2026-05-25)

---

**Vault Source:** brand-config.json (2026-06-22)  
**Next Update:** Weekly sync via vault-sync.sh
