---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Selong-Selo/Content/Week-3-Film-List-2026-08-17.md
mtime: 2026-08-17 21:00:11 WITA
brand: Selong-Selo
title: Week 3 Film List 2026 08 17
date_range: n/a
exported: 2026-09-14
---

# Selo film list · 17 Aug 2026
Do not schedule. Handle @selo.properties. No invented listings, prices, villa counts, or availability. No stay CTA.

Covers FILM items across 17–23, 24–30, and the combined 31–13 fortnight draft.
July “no on-camera talent” rule is not in these drafts — Annalise posts now say on-camera allowed.

## Thu 27 Aug — Annalise on Serangan Indah
Need: Annalise on camera at Serangan Indah. Catalogue Annalise = 0, Serangan = 0. Land stills are not this post.

## Tue 1 Sep — POV turnkey villa
Need: guests / pool / payout screen as ownership POV. Turnkey = 0, payout = 0. GGV stay pool/guest clips are stay content — do not use as a stay CTA.

## Thu 3 Sep — Annalise on Serangan Indah
Same gap as Thu 27. Do not schedule until shot.

## Sat 12 Sep — Owner arriving / familiar staff
Need: owner arriving, familiar staff. Suite stills are not this post.
Nearby, not this post: IMG_6247.MOV (11 Apr 2026) couple arriving for dinner — GGV stay.
