---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Selong-Selo/Selong-Strategy.md
mtime: 2026-06-23 19:45:38 WITA
brand: Selong-Selo
title: Selong Strategy
date_range: n/a
exported: 2026-09-14
---

---

## Related Files

- [[Selong-Brand|01-Wolf-Command/Brands/Selong-Selo/Selong-Brand.md]]
- [[Habitat-Strategy|01-Wolf-Command/Brands/Habitat-Villas/Habitat-Strategy.md]]
- [[Atlas-Overview|01-Wolf-Command/Atlas-System/SOPs/Atlas-Overview.md]]
- [[Theme-Bank-Master|01-Wolf-Command/Atlas-System/Theme-Bank/Theme-Bank-Master.md]]
- [[Style-Profiles|01-Wolf-Command/Team/Content-Team/Style-Profiles.md]]

brand: Selo
display: Selo
company: GGV
type: brand-strategy
source: Brand-Assets/GGV/Selo/content-strategy/Selo-{Lifestyle,Elevated-Living,Smart-Ownership}-Pillar.pdf + Selo-Brand-Identity.pdf + Selo-Suite-Villas-Brochure.pdf (NAS; owner 2026-06-21)
fonts: { display: "Aviano Sans", body: "Gotham", accent: "Alegreya" }
---

# Selo — Content Strategy

**One line:** Selo (Selong Selo Resort & Villas / Selo Suite Villas, by Goss Group) sells
*destination desire and confidence* first; ownership becomes the natural conclusion. "You are
welcome — a diversified real estate and hospitality company with a purpose."

## Voice
Elevated · calm · sophisticated · trustworthy · restrained. Never hype, never a finance deck.
Confidence over claims. Many buyers are international and don't yet know Lombok.

## Three content pillars
1. **South Lombok Lifestyle** — sell the destination before the property; South Lombok itself is
   the product. "I want to be in South Lombok," not "I want to buy a villa."
2. **Elevated Living** — answer "what is life actually like here?" The experience of living in the
   Selong Selo ecosystem; bridges hospitality, lifestyle and ownership. Make people imagine
   themselves there, not sell a villa.
3. **Smart Ownership** — make ownership feel understandable, trustworthy, desirable WITHOUT being
   financial/technical/salesy. Sells *confidence*, not returns; shows the ecosystem, operations,
   and demand behind the numbers. "Ownership here makes sense," arrived at, not pushed.

## Brand identity (selo1)
- Parent palette: **Matte Gold #AB9472** (Pantone 7503C), **Charcoal #2B2E2E**, **Cool Grey
  #C4CFD5**. Selo Suite Villas sub-brand: teal **#277182** + #548C92 / #B4D7D8 / #E0D7CF.
- Type: **Aviano Sans** (headings, bold/medium) + **Gotham** (subheads/body, medium/book).
- Brochure design language (Selo Suite Villas): centred, UPPERCASE Aviano headline + thin hairline
  rule, centred subhead, logo top-centre — already encoded in the Selo story template.

## ⚠️ Palette discrepancy to resolve
`brand-config.json` "Selo" palette is currently sand/green/soft-yellow/beige/dark-grey — it
matches **neither** the parent Matte Gold/Charcoal/Cool Grey identity **nor** the Selo Suite Villas
teal palette in selo1. Left UNCHANGED pending owner decision (it's high-impact: flows through Selo
reels + graphics, and selo1 lists many portfolio palettes so the "canonical Selo" set is a choice).

## Template implications
Uppercase Aviano headline + centred hairline rule (brochure keyline) on a luxury hero — already in
the Selo story template. Tone = restraint as the luxury cue.
