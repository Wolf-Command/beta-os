---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Selong-Selo/Content/Selo-Content-Plan-2026-08-31-13-DRAFT.md
mtime: 2026-08-17 20:54:47 WITA
brand: Selong-Selo
title: Selo Content Plan 2026 08 31 13 DRAFT
date_range: 2026-08-31 to 2026-09-13
exported: 2026-09-14
---

# Selo fortnight draft · 31 Aug–13 Sep 2026 · honesty pass

Status: DRAFT. Handle @selo.properties. Foreign buyer. Nothing posted.
LEARN was Mon/Wed/Fri. Locked cadence is Tue/Thu/Sat — remapped. No prices. No villa counts. No stay CTA.
CTA selogroup.co / DM SELO.

## Tue 1 FILM
POV you bought a turnkey villa. Guests / pool / payout screen = FILM. Do not mix a stay CTA.

## Thu 3 FILM
Annalise on Serangan Indah. Do not schedule until shot.

## Sat 5 MATCH
Listings carousel. No prices. No counts.
1 hook "what’s currently available"
2 categories "suite · land · villa"
3 CTA "DM SELO · selogroup.co"

## Tue 8 MATCH
Ask the right questions. Copy + ops stills if we have them.
1 hook "the best investors ask"
2 "who manages · who cleans · who fills"
3 CTA "selogroup.co"

## Thu 10 MATCH
Still early South Lombok. Coast / road. No invented tourism %.
1 coast "before everyone else"
2 south lombok "quietly growing"
3 CTA "selogroup.co"
Then/now airport pair = FILM.

## Sat 12 FILM
Come back whenever — owner arriving / familiar staff. Suite stills are not this post. Do not schedule until shot.
