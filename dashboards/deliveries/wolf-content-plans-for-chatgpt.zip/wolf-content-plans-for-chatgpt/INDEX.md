# Wolf Command Content Plans — Export for ChatGPT
- Vault: `/Users/wolfterminal/WolfCommandSystem/WolfCommand`
- Exported: 2026-09-14
- Mode: READ-ONLY copy; vault files not modified
- Sanitization: lines matching password/API key/token patterns omitted; URLs preserved

## Brands with plans

| Brand | Plan | Date range | Original source | Supporting docs |
|---|---|---|---|---|
| Habitat-Villas | Habitat-Content-Plan-2026-09-07-13-DRAFT.md | 2026-09-07 to 2026-09-13 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Habitat-Villas/Content/Habitat-Content-Plan-2026-09-07-13-DRAFT.md` | Habitat-Brand.md, Habitat-Strategy.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Habitat-Villas | Habitat-Content-Plan-2026-09-14-27-DRAFT.md | 2026-09-14 to 2026-09-27 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Habitat-Villas/Content/Habitat-Content-Plan-2026-09-14-27-DRAFT.md` | Habitat-Brand.md, Habitat-Strategy.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Habitat-Villas | Habitat-Content-Plan-2026-08-31-13-DRAFT.md | 2026-08-31 to 2026-09-13 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Habitat-Villas/Content/Habitat-Content-Plan-2026-08-31-13-DRAFT.md` | Habitat-Brand.md, Habitat-Strategy.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Atrium | Atrium-Content-Plan-2026-09-14-27-DRAFT.md | 2026-09-14 to 2026-09-27 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/02-Atrium/Content/Atrium-Content-Plan-2026-09-14-27-DRAFT.md` | Atrium-Strategy.md, Atrium-Brand.md, FILM-14-27-Sep-2026.md, Week-1-Film-List-2026-08-17.md, Week-3-Film-List-2026-08-17.md |
| Atrium | Atrium-Content-Plan-2026-08-31-13-DRAFT.md | 2026-08-31 to 2026-09-13 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/02-Atrium/Content/Atrium-Content-Plan-2026-08-31-13-DRAFT.md` | Atrium-Strategy.md, Atrium-Brand.md, FILM-14-27-Sep-2026.md, Week-1-Film-List-2026-08-17.md, Week-3-Film-List-2026-08-17.md |
| Atrium | Atrium-Content-Plan-2026-08-24-30-DRAFT.md | 2026-08-24 to 2026-08-30 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/02-Atrium/Content/Atrium-Content-Plan-2026-08-24-30-DRAFT.md` | Atrium-Strategy.md, Atrium-Brand.md, FILM-14-27-Sep-2026.md, Week-1-Film-List-2026-08-17.md, Week-3-Film-List-2026-08-17.md |
| Uma-Blu | Uma-Blu-Content-Plan-2026-09-14-27-DRAFT.md | 2026-09-14 to 2026-09-27 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Uma-Blu/Content/Uma-Blu-Content-Plan-2026-09-14-27-DRAFT.md` | Uma-Blu-Brand.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Uma-Blu | Uma-Blu-Content-Plan-2026-08-31-13-DRAFT.md | 2026-08-31 to 2026-09-13 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Uma-Blu/Content/Uma-Blu-Content-Plan-2026-08-31-13-DRAFT.md` | Uma-Blu-Brand.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Uma-Blu | Uma-Blu-Content-Plan-2026-08-24-30-DRAFT.md | 2026-08-24 to 2026-08-30 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Uma-Blu/Content/Uma-Blu-Content-Plan-2026-08-24-30-DRAFT.md` | Uma-Blu-Brand.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Tropik-Resorts | Tropik-Content-Plan-2026-09-14-27-DRAFT.md | 2026-09-14 to 2026-09-27 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Tropik-Resorts/Content/Tropik-Content-Plan-2026-09-14-27-DRAFT.md` | Tropik-Brand.md, Tropik-Strategy.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Tropik-Resorts | Tropik-Content-Plan-2026-08-31-13-DRAFT.md | 2026-08-31 to 2026-09-13 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Tropik-Resorts/Content/Tropik-Content-Plan-2026-08-31-13-DRAFT.md` | Tropik-Brand.md, Tropik-Strategy.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Tropik-Resorts | Tropik-Content-Plan-2026-08-24-30-DRAFT.md | 2026-08-24 to 2026-08-30 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Tropik-Resorts/Content/Tropik-Content-Plan-2026-08-24-30-DRAFT.md` | Tropik-Brand.md, Tropik-Strategy.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Selong-Selo | Selo-Content-Plan-2026-09-14-27-DRAFT.md | 2026-09-14 to 2026-09-27 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Selong-Selo/Content/Selo-Content-Plan-2026-09-14-27-DRAFT.md` | Selong-Brand.md, Selong-Strategy.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Selong-Selo | Selo-Content-Plan-2026-08-31-13-DRAFT.md | 2026-08-31 to 2026-09-13 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Selong-Selo/Content/Selo-Content-Plan-2026-08-31-13-DRAFT.md` | Selong-Brand.md, Selong-Strategy.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |
| Selong-Selo | Selo-Content-Plan-2026-08-24-30-DRAFT.md | 2026-08-24 to 2026-08-30 | `/Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Selong-Selo/Content/Selo-Content-Plan-2026-08-24-30-DRAFT.md` | Selong-Brand.md, Selong-Strategy.md, FILM-14-27-Sep-2026.md, Week-3-Film-List-2026-08-17.md |

## Brands searched — no content plans

- **BZG**: Found as Brands/BZG-Venues and 03-BZG; no *Content-Plan* files. BZG-Bar-Venues.md exists but is venue notes, not a content plan.
- **AMG**: No AMG brand folder or *Content-Plan* files. Agent-AMG.md under 02-Atrium/Operations only (ops agent notes).

## Notes

- Brand names reported as found in vault (no silent aliases: BZG ≠ Uma-Blu).
- Top 3 plans per brand by mtime; on ties prefer later date_range in filename; prefer DRAFT over LEARN for Atrium #3.
- Supporting capped ≤5 per brand: brand sheet, strategy, film/production lists in same brand folder (or linked Atrium-Lombok brand sheet).
- Secret-like lines omitted across export: 0
