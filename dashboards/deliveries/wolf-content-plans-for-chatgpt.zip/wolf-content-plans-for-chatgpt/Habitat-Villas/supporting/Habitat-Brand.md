---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Habitat-Villas/Habitat-Brand.md
mtime: 2026-06-23 19:45:38 WITA
brand: Habitat-Villas
title: Habitat Brand
date_range: n/a
exported: 2026-09-14
---

# Habitat Villas — Complete Brand Knowledge

**Client:** GGV (Goss Group Ventures)  
**Company:** PT Keen Eye (property owner — GGV provides S&M)  
**Brand Type:** Luxury villa development (3 projects)  
**Status:** COMPLETE (text_style fully configured)  
**Last Updated:** 2026-06-22 (from brand-config.json)

## Related Files

- [[Habitat-Strategy|01-Wolf-Command/Brands/Habitat-Villas/Habitat-Strategy.md]]
- [[GGV-Brand|01-Wolf-Command/Brands/GGV/GGV-Brand.md]]
- [[Theme-Bank-Master|01-Wolf-Command/Atlas-System/Theme-Bank/Theme-Bank-Master.md]]
- [[Style-Profiles|01-Wolf-Command/Team/Content-Team/Style-Profiles.md]]


---

## ESSENCE & VOICE

**Brand Essence:** Considered living, quiet luxury, design-literate restraint, authenticity  
**Voice Descriptors:**
- property-portfolio polish
- clean architecture
- lifestyle aspirational

**Tone:** Architectural journal-style (NO "luxury", "stunning", "don't miss out" clichés). Restrained, specific (name materials), design-literate.

---

## THE THREE PROJECTS

1. **Habitat Forest (Habitat 1)** — Kuta hillside, ocean view near Mandalika circuit. 10 villas. SOLD OUT, performing well.
2. **Habitat Garden (Habitat 2)** — Kuta Eat Street, main Kuta road. 18 villas. SOLD OUT, construction halfway done, finished units hosting guests.
3. **Habitat Vibe (Habitat 3)** — Heart of Kuta, 500m from Kuta Beach. 31 villas. Some sold, some available. Early construction phase, foundations laid.

**Content Update Cadence:** Every Friday 09:00 WITA. Developer Matt discusses construction progress, names owners for familiarity/trust.

---

## COLOR PALETTE

| Role | Hex | Name | Used In |
|------|-----|------|----------|
| Primary | `#79755B` | Warm Brown | Headlines, buttons, bottom bar |
| Secondary | `#EAE6D7` | Cream | Body text, highlights |
| Alt Primary | `#A6A28B` | Warm Brown (Light) | Accents, secondary elements |
| White | `#FFFFFF` | White | Contrast, fills |
| Dark | `#232224` | Charcoal | Outlines, shadows, text depth |

**Bottom Bar:** `#79755B` at 0.7 opacity  
**Label Color:** `#FFFFFF` (white text on dark bar)

---

## TYPOGRAPHY

**Primary Typeface:** Manrope  
**Font File:** `fonts/Habitat-Manrope.zip`

| Role | Family | Weight | File | Usage |
|------|--------|--------|------|-------|
| Headline | Manrope | ExtraBold | Manrope-ExtraBold.ttf | Video captions, headlines |
| Hook | Manrope | ExtraBold | Manrope-ExtraBold.ttf | Eye-catching openers |
| Body | Manrope | SemiBold | Manrope-SemiBold.ttf | Main copy, body text |
| Caption | Manrope | Bold | Manrope-Bold.ttf | Lower captions, labels |
| Lower-Third | Manrope | Bold | Manrope-Bold.ttf | Bottom-bar text |
| Display (graphics) | Manrope | ExtraBold | Manrope-ExtraBold.ttf | Branded graphics |
| Sans (graphics) | Manrope | Medium | Manrope-Medium.ttf | Secondary graphics |

**Text Style Config:**
- **Headline:** Fill=Secondary(cream), Highlight=White, Outline=Dark, Active=Primary(brown)
- **Hook:** Same as headline (fill cream, outline dark)
- **Body:** Same palette mapping
- **Caption:** Same palette mapping
- **Lower-Third:** Fill=White, Highlight=Secondary, Outline=Dark (inverted for contrast on dark bar)

---

## LOGOS

**Asset Root:** `/Volumes/01-Media-Library/Brand-Assets/GGV/Habitat`

| Logo | Path | Usage |
|------|------|-------|
| Primary Wordmark | `logos/Habitat_Villas_logo.png` | Color version |
| Primary Wordmark (white) | `logos/Habitat_Villas_logo_white.png` | On dark backgrounds |
| Icon | `logos/Habitat_icon.png` | Favicon, small marks |
| Icon (white) | `logos/Habitat_icon_white.png` | On dark, highlight |

**Logo Placement (Default):**
- Position: Top-left
- Size: 20% of frame width
- Margin: 5% from edge

---

## VISUAL LANGUAGE

- Architectural details (shadow lines, handles, window reveals)
- Clean sky facades, no scaffolding visible
- Golden hour light, interior-to-exterior frames
- Honest materials: concrete, timber, stone patina over time
- Lifestyle: morning routine, quiet moments, aspirational domesticity
- NO handheld wobble, NO trending audio — curated, not algorithmic

---

## CONTENT PILLARS

1. **Considered design** — every detail earns its place
2. **Quiet luxury of space** — generous proportions, natural light
3. **Community without compromise** — connected, calm
4. **Materials aging beautifully** — texture, patina, longevity
5. **Weekend morning energy** — aspirational unhurried life

---

## VIDEO GRADING & MUSIC

**Reel Engine Slug:** `habitat`  
**Grading:** Professional color curve (warm, lifted mids, cool shadows)
- Master curve: `0/0 0.08/0.055 0.35/0.37 0.65/0.68 0.92/0.96 1/1`
- Red channel: Enhanced warmth
- Blue channel: Lifted shadows
- Saturation: +12%, Contrast: +4%

**Music:** `cinematic-clear-skies.mp3` (instrumental, contemporary)  
**Pacing:** Medium (not rushed, not static)

**Reel Engine Codes (for auto-matching):**
- habitat
- hab
- habitat garden
- habitat_warm

---

## NAS & ASSET LOCATION

**NAS Path:** `/Volumes/01-Media-Library/Brand-Assets/GGV/Habitat`

**Folder Structure:**
```
Habitat/
├── fonts/
│   └── Habitat-Manrope.zip
├── logos/
│   ├── Habitat_Villas_logo.png
│   ├── Habitat_Villas_logo_white.png
│   ├── Habitat_icon.png
│   └── Habitat_icon_white.png
├── style-guides/ (brand PDFs)
├── raws/ (raw footage)
├── finished/ (exported assets)
└── graphics/ (design templates)
```

---

## CONTENT PERFORMANCE

**Instagram Grid Strategy (Editorial):**
- **Color rhythm:** 60% warm earth tones (brown, cream, olive) / 40% cool (sky blue, white)
- **Saturation:** Alternates high-low for visual breathing room
- **Typography:** Geometric sans, lowercase-only, medium-semibold headlines with light subcopy
- **Text Placement:** Zigzag (top ↔ bottom) creates dynamic eye movement
- **Content Ratio:**
  - 35% construction (proof of work)
  - 25% lifestyle (aspiration)
  - 20% founder/investor (trust)
  - 20% architecture/location (positioning)

**Narrative Arc:**
- Timing → Lifestyle → Construction Proof → Post-Completion Outcomes → ROI Education

---

## APPROVAL & TEAM

**Content Lead (Reviewer):** Nindy (GGV)  
**Editor:** Haikal (GGV)  
**Director/Approver:** Mr Wolf, Amanda (GGV GM)

**Style Profile:** See `/01-Wolf-Command/Team/Content-Team/Style-Profiles.md` (Nindy, Haikal)

---

## BRAND CONFIG STATUS

**Text Style:** COMPLETE (full role map + font assignments)  
**Intro/Outro:** Standard (default outro enabled)  
**Reel Engine:** MIGRATED (grading + music + pacing verified 2026-05-25)  
**Font Status:** COMPLETE (Manrope installed locally + NAS)

---

**Vault Source:** brand-config.json (2026-06-22)  
**Next Update:** Weekly sync via vault-sync.sh
