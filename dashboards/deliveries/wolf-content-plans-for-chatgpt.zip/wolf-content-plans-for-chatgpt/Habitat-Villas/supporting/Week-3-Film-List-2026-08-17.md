---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Habitat-Villas/Content/Week-3-Film-List-2026-08-17.md
mtime: 2026-08-17 21:00:11 WITA
brand: Habitat-Villas
title: Week 3 Film List 2026 08 17
date_range: n/a
exported: 2026-09-14
---

# Habitat film list · fortnight 31 Aug–13 Sep · 17 Aug 2026
Nothing posts. Catalogue newest capture: 18 Jun 2026.
Source: MATCH-31-Aug-13-Sep-2026.md + Habitat-Content-Plan-2026-08-31-13-DRAFT.md (combined fortnight; split 31–06 / 07–13 gone). DRAFT files not touched.

## Must film
- Fri 4 Sep — Matt + Meisya send photos. Meisya 0. No Matt+Meisya set.
- Fri 11 Sep — hosted walk around Vibe with Matt (sit-down or walk-and-talk). 15 Jun lav walkaround exists; it cannot carry this. Comedy interrupt stays FILM.
- Prospectus collage — 0 on Habitat NAS. Do not fake a Habitat prospectus.
- Stories “Matt update video” / talking-head — still 0. Lav is not talking-head.

## Copy-only (not a film item)
- Mon 31 Aug slide 1 “Bali problem” — no Bali clip. Graphic/copy. Garden vs Vibe files are real; do not flip the post.

## Can use now
- Garden finished: IMG_5620 bedroom 22 Jan 2026, IMG_5588 bathroom 22 Jan 2026, IMG_1137 kitchen 8 Dec 2025, Masashi tour, garden_walkaway 17 Jun
- Vibe steel 15–18 Jun: drone_contruction_5, contruction_1, welding_1, _3/_4 foundations
- PVC/water: IMG_0722 5 Jun 2026; pipes on contruction_5 18 Jun
- Solar 29 May (IMG_0355); access road 30 Apr (IMG_8201)
