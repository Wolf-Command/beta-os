---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Habitat-Villas/Habitat-Strategy.md
mtime: 2026-06-23 19:45:38 WITA
brand: Habitat-Villas
title: Habitat Strategy
date_range: n/a
exported: 2026-09-14
---

---

## Related Files

- [[Habitat-Brand|01-Wolf-Command/Brands/Habitat-Villas/Habitat-Brand.md]]
- [[GGV-Brand|01-Wolf-Command/Brands/GGV/GGV-Brand.md]]
- [[Theme-Bank-Master|01-Wolf-Command/Atlas-System/Theme-Bank/Theme-Bank-Master.md]]
- [[Style-Profiles|01-Wolf-Command/Team/Content-Team/Style-Profiles.md]]

brand: Habitat
display: Habitat
company: GGV
type: brand-strategy
source: brand kit + branding guide (NO finished examples in craft-db — raw-only) — 2026-06-21
fonts: { display: "Manrope ExtraBold", body: "Manrope Medium" }
status: KIT-BASED — best-effort, NOT finished-validated. Tune when the team drops finished Habitat statics/reels.
---

# Habitat — Strategy (kit-based, best-effort)

**One line:** Habitat Villas — modern architectural property portfolio. Clean, confident,
lifestyle-aspirational. Sub-brands: **Habitat Garden**, **Habitat Vibe**.

## Voice
Property-portfolio polish · clean architecture · lifestyle aspirational. Modern and direct (the
brand font is a geometric sans, not a serif) — confident statements, not flowery copy.

## Identity
- Type: **Manrope** — ExtraBold for bold uppercase headlines (display), Medium/SemiBold for
  body/labels.
- Palette: Primary #79755B (olive-taupe), Secondary #EAE6D7 (cream), Alt Primary #A6A28B, White
  #FFFFFF, Dark #232224. Headlines typically the light cream (secondary) over photography.

## Template implications (current)
Modern property story: bold **uppercase Manrope ExtraBold** headline (cream), clean Manrope sans
subhead/CTA, full-frame with generous air, subtle logo, no decorative shape. Already in the
Habitat story template.

## ⚠️ Honesty
Habitat is **raw-only** in craft-db — there is no finished Habitat static or reel to validate
against. Everything here is reasoned from the kit + brand guide. The template is a sound
best-effort but should be tuned the moment the team drops a finished Habitat example.
