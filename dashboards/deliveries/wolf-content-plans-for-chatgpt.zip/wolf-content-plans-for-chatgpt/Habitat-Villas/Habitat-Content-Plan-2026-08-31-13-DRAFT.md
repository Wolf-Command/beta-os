---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Habitat-Villas/Content/Habitat-Content-Plan-2026-08-31-13-DRAFT.md
mtime: 2026-08-17 20:54:47 WITA
brand: Habitat-Villas
title: Habitat Content Plan 2026 08 31 13 DRAFT
date_range: 2026-08-31 to 2026-09-13
exported: 2026-09-14
---

# Habitat fortnight draft · 31 Aug–13 Sep 2026 · honesty pass

Status: DRAFT. Live handle @habitat.lombok. Nothing posted.
No villa counts. No stay CTA. No 85% / 80% occ. No 15% ROI.

## Mon 31 MATCH
Why Lombok, not Bali. Garden finished vs Vibe steel. LEARN slide 6 (85% / 15%) dropped.
1 Bali problem "supply · not a lego box"
2 Lombok still "this island instead"
3 Garden vs Vibe "built · and building"
4 CTA "DM lombok · or the prospectus"
Stories: Bali/Lombok poll. Tour CTA on a site still — Matt update video = FILM.

## Wed 2 MATCH
Income levers as copy. No occupancy %.
1 hook "not just the nightly rate"
2 three levers "rate · filled nights · extras"
3 Habitat "we build and manage for all three"
4 CTA "DM for the breakdown"
Prospectus collage = FILM (not in catalogue). Tue guest/OTA review story DROPPED (stay lean).

## Fri 4 FILM
Matt + Meisya “send photos.” Meisya 0. Matt talking-head 0. Do not schedule until shot.

## Mon 7 MATCH
Low risk as a checklist. LEARN “over 80% occupancy” dropped.
1 hook "low risk is a checklist"
2 walkable build "steel · water · materials you can see"
3 structure "clear ownership · a manager who answers"
4 CTA "DM for the breakdown"
Stories: quiz on the three checks. Tour on a site still. Matt video = FILM.

## Wed 9 MATCH
Turnkey = Garden finished (Dec 2025 / Jan 2026). Guests arriving, Pink Nusa, OTA reviews = FILM / stay lean — dropped from this post.
1 Garden finished "turnkey · already standing"
2 named "you do not run the nights"
3 CTA "DM invest"
No occupancy. No ROI number.

## Fri 11 FILM
Walk around Vibe with Matt. No talking-head. Lav walkaround cannot carry it. Do not schedule until sit-down or walk-and-talk is shot.
One comedy interrupt stays FILM (sit-down does not exist).
