---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Habitat-Villas/Content/Habitat-Content-Plan-2026-09-07-13-DRAFT.md
mtime: 2026-09-06 12:01:03 WITA
brand: Habitat-Villas
title: Habitat Content Plan 2026 09 07 13 DRAFT
date_range: 2026-09-07 to 2026-09-13
exported: 2026-09-14
---

# Habitat firstcut prove week · 7–13 Sep 2026 · Delivery Spec

Status: **DRAFT · FIRSTCUT THAW ONLY** (Peaches 6 Sep). Other brands stay frozen. Nothing posts.
Handle: `@habitat.lombok`. Investor brand. Proof not promise.
Hard drops on *feed overlays* until Matthew/Peaches unlock: no live villa-count scarcity · no stay CTA · no flattened 85%/80% occ or 15% ROI slogans · no invented fees.
Brand law (6 Sep Peaches CORRECTION — do not conflate):
- **Prospectus PDF only:** `/assets/habitat/Habitat-Prospectus-2026-09-06.pdf` (also `briefs/habitat/`) — prospectus CTA → PDF
- **Investment Report:** page `https://dash.wolfcommand.net/habitat-investment-2026.html` + PPTX `/assets/habitat/Habitat-Lombok-Investment-Report-2026.pptx` — investment report CTA → page/PPTX (not prospectus HTML)
Claims for investment slides must trace prospectus PDF; see `briefs/habitat/HABITAT-PROSPECTUS-BRAND-LAW-2026-09-06.md`. Scarcity/ROI **GATED**. CF Access gated until Matthew public bypass.
FILM does not schedule. Peaches owns thaw mechanics. Muse owns plan cards only.
Scout gate: Muse brief → Indigo match → Velvet pack → human approve → schedule.

**Prove week pick:** Mon **7 Sep** – Sun **13 Sep 2026**  
Why: next full Habitat cadence week from today (Sun 6); aligns with locked honesty beats already in `Habitat-Content-Plan-2026-08-31-13-DRAFT.md` (Mon 7 / Wed 9 / Fri 11). Raw→polish prove before widen.

Cadence lock: **Mon / Wed / Fri** feed · **2 stories / day** every calendar day (incl. Sun).

Themes only — angles that prove the claim. **Not** camera shot lists.

---

## Mon 7 Sep · Post 1 · MATCH

| Field | Value |
|---|---|
| Day + date | Monday 7 Sep 2026 |
| Post # + title | Post 1 — Low Risk Is a Checklist? |
| Format | CAROUSEL · 4 SLIDES |
| Pillar | Investor Q / Trust |
| CTA | DM `LOMBOK` · Prospectus PDF `/assets/habitat/Habitat-Prospectus-2026-09-06.pdf` · or Investment Report page https://dash.wolfcommand.net/habitat-investment-2026.html (+ PPTX `/assets/habitat/Habitat-Lombok-Investment-Report-2026.pptx`) — do not conflate; CF Access gated until Matthew public bypass |
| Hashtags | #HabitatVibe #KutaLombok #LombokProperties #LombokInvestment #KutaVilla |
| Caption angle | Three checks a serious buyer can verify on site — no occupancy %; no ROI number. Honesty pass from 31 Aug–13 LEARN. |

### Slide table

| Slide | On-screen text | Purpose |
|---|---|---|
| 1 | Low risk is a checklist. | Hook · invite swipe |
| 2 | Steel · water · materials you can see. | Build you can walk |
| 3 | Clear ownership · a manager who answers. | Structure you can name |
| 4 | DM for the breakdown. | Soft CTA |

### Per-slide delivery (angles — not shot lists)

**Slide 1**
1. Visual intent: PROVE this is a buyer checklist, not a hype splash.
2. Footage / still angle: quiet Habitat exterior or clean graphic cover — space over clutter.
3. Avoid: villa-count scarcity; ROI/occ graphics; stay/Airbnb framing; busy data on cover.
4. Text hierarchy: one big line · tiny support · ~75% visual.

**Slide 2**
1. Visual intent: PROVE the build is inspectable (materials / progress you can walk).
2. Footage / still angle: unfinished-or-finished structure that shows real works — Garden/Vibe context only if Indigo has a match.
3. Avoid: glossy render-only; bathroom/pool beauty that does not prove “checklist”.
4. Text hierarchy: three short nouns · negative space.

**Slide 3**
1. Visual intent: PROVE ownership path + human accountability — words over fake certificates.
2. Footage / still angle: simple two-label graphic or calm site still; no fake paperwork stills.
3. Avoid: nominee how-to; invented fee tables; guest OTA review cards.
4. Text hierarchy: two short claims · rest in caption.

**Slide 4**
1. Visual intent: invite a real conversation — not a booking engine.
2. Footage / still angle: Habitat exterior + small CTA bar.
3. Avoid: stay CTAs; villa counts; invented % returns.
4. Text hierarchy: CTA small under still.

**Stories (2):** quiz “Which check first — build / ownership / manager?” · tour CTA on a site still (Matt update video = FILM — do not force).

---

## Wed 9 Sep · Post 2 · MATCH

| Field | Value |
|---|---|
| Day + date | Wednesday 9 Sep 2026 |
| Post # + title | Post 2 — Turnkey Means It’s Already Standing |
| Format | CAROUSEL · 3 SLIDES |
| Pillar | Project Spotlight / Habitat Brand |
| CTA | DM `INVEST` · or Investment Report page https://dash.wolfcommand.net/habitat-investment-2026.html (+ PPTX `/assets/habitat/Habitat-Lombok-Investment-Report-2026.pptx`) — not prospectus PDF |
| Hashtags | #HabitatVibe #KutaLombok #LombokProperties #LombokInvestment #KutaVilla |
| Caption angle | Garden finished (Dec 2025 / Jan 2026 window from prior LEARN) = turnkey standing. You do not run the nights. No occupancy. No ROI. Pink Nusa / OTA guest reviews = stay-lean — **dropped** from this post. |

### Slide table

| Slide | On-screen text | Purpose |
|---|---|---|
| 1 | Turnkey · already standing. | Cover · finished Garden |
| 2 | You do not run the nights. | Management as owner choice |
| 3 | DM invest. | Soft CTA |

### Per-slide delivery (angles — not shot lists)

**Slide 1**
1. Visual intent: PROVE finished product exists — standing Garden, not a promise render alone.
2. Footage / still angle: completed Garden exterior / street approach that reads “done”.
3. Avoid: Vibe-under-construction as “turnkey”; stay bedroom beauty; villa counts.
4. Text hierarchy: short cover · lots of space.

**Slide 2**
1. Visual intent: PROVE hands-off ownership angle — management is an option, never a fee comparison.
2. Footage / still angle: calm interior or amenity still that reads “cared for”, not a nightly-rate sheet.
3. Avoid: occupancy %; 15% ROI; OTA guest review screenshots; “sleep here” language.
4. Text hierarchy: one line · caption carries nuance.

**Slide 3**
1. Visual intent: back to investment conversation.
2. Footage / still angle: Habitat brand still + CTA.
3. Avoid: Booking/stay CTAs; scarcity villa counts.
4. Text hierarchy: CTA small.

**Stories (2):** “Finished or still building — which matters more to you?” poll · Prospectus CTA = PDF only; Investment Report CTA = page/PPTX (split 6 Sep; CF gated).

---

## Fri 11 Sep · Post 3 · FILM (gated)

| Field | Value |
|---|---|
| Day + date | Friday 11 Sep 2026 |
| Post # + title | Post 3 — A Walk Around Site with Matt? |
| Format | REEL (or copy carousel if flipped MATCH) |
| Pillar | Weekly Build Update / Personality |
| CTA | DM `LOMBOK` · tour ask |
| Gate | **FILM** — Matt walk-and-talk or sit-down required. Lav walkaround alone cannot carry it. Do not schedule until shot or flipped to graphic MATCH. |
| Hashtags | #HabitatVibe #KutaLombok #LombokProperties #OneMinuteWithMatt |
| Caption angle | Site truth from Matt — progress you can see. No villa counts. No ROI. No stay pitch. |

### Beat table (when filmed — themes, not a cut list)

| Beat | On-screen text | Purpose |
|---|---|---|
| 1 | Walk the site with me. | Hook · presence |
| 2 | What’s finished · what’s next. | Progress honesty |
| 3 | Ask me the hard question. | Soft CTA / DM |

### Per-beat delivery (angles — not shot lists)

**Beat 1**
1. Visual intent: PROVE Matt is on site — place + person together.
2. Footage angle: walk-and-talk open; if unshot, do **not** fake with B-roll only — flip to MATCH graphic or hold FILM.
3. Avoid: stock drone with no Matt; comedy interrupt without sit-down (prior FILM hold).
4. Text hierarchy: short hook · voice leads.

**Beat 2**
1. Visual intent: PROVE then/now without invented dates or counts.
2. Footage angle: two clear contexts (finished vs in-progress) Matt can point at.
3. Avoid: occupancy/ROI overlays; villa remaining counts.
4. Text hierarchy: few words · Matt’s line carries.

**Beat 3**
1. Visual intent: invite DM — investor conversation, not OTA book.
2. Footage angle: end on Habitat / Matt looking to camera.
3. Avoid: stay CTAs; rate cards.
4. Text hierarchy: CTA end card small.

**Stories (2):** “What should Matt answer next?” text sticker · site still with tour CTA (no forced Matt clip).

---

## Stories spine · Tue / Thu / Sat / Sun (no feed post)

All days still run **2 stories**. Keep investor brand. No stay lean.

| Day | Story A (angle) | Story B (angle) |
|---|---|---|
| Tue 8 | Poll: checklist item that matters most | Site still · soft tour |
| Thu 10 | “Finished Garden or building Vibe?” | Investment Report page/PPTX · or Prospectus PDF · or soft DM — do not conflate |
| Sat 12 | One honest buyer FAQ sticker | Brand still · no villa count |
| Sun 13 | Week recap sticker (3 posts named) | Soft DM `LOMBOK` |

---

## Honesty + gate checklist

- [x] Prove week = 7–13 Sep (MWF · 3 feed · 2 stories/day)
- [x] Delivery Spec cards (slide table + visual_intent / avoid / hierarchy)
- [x] Themes/angles — no camera cut lists that steal the shoot
- [x] No villa counts · no occ% · no 15% ROI · no stay CTA
- [x] Fri 11 FILM gated
- [ ] Indigo match / Velvet pack — after Peaches thaw mechanics
- [ ] Nothing posted

## Sources (no invent)

- Peaches lock 6 Sep: Habitat firstcut thaw only; other brands frozen
- Cadence: CLIENT-NOTES / Content-Plan-Build-Rules (Habitat MWF · 2 stories/day)
- Honesty beats: `Habitat-Content-Plan-2026-08-31-13-DRAFT.md` Mon 7 / Wed 9 / Fri 11
- Format: `CONTENT-PLAN-DELIVERY-SPEC-2026-09-05.md` + Habitat 14–27 delivery rewrite learn

---

*Muse · 6 Sep 2026 WITA · DRAFT firstcut · report path to Peaches · nobody posts*
