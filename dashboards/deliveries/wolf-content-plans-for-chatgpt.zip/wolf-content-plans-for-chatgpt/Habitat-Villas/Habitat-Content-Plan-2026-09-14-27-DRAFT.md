---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Habitat-Villas/Content/Habitat-Content-Plan-2026-09-14-27-DRAFT.md
mtime: 2026-09-05 21:25:53 WITA
brand: Habitat-Villas
title: Habitat Content Plan 2026 09 14 27 DRAFT
date_range: 2026-09-14 to 2026-09-27
exported: 2026-09-14
---

# Habitat fortnight draft · 14–27 Sep 2026 · delivery format

Status: DRAFT. Delivery Spec 5 Sep. Live handle `@habitat.lombok`. Nothing posted.
Brand law: Proof not promise. No villa counts. No stay CTA. No 85%/80% occ. No 15% ROI. Foreign buyer.
FILM does not schedule. Catalogue newest 18 Jun unless Indigo rematches.
Metricool (17 Aug–5 Sep, real): carousels dominate; best reach 657 on 19 Aug. No invented numbers.
Scout gate: Muse brief → Indigo match → Velvet pack → human approve → schedule.

Cadence: Mon/Wed/Fri · 6 posts · 2 stories/day.

---

## Mon 14 Sep · Post 1 · MATCH (graphic/copy; Matt TH = FILM)

| Field | Value |
|---|---|
| Day + date | Monday 14 Sep 2026 |
| Post # + title | Post 1 — Questions Every Kuta Buyer Is Asking Me Right Now? |
| Format | CAROUSEL · 4 SLIDES |
| Pillar | Informational / Trust |
| CTA | DM `LOMBOK` · or the prospectus |
| Hashtags | #HabitatVibe #KutaLombok #LombokProperties #LombokInvestment #KutaVilla |
| Caption angle | Answer all four in the caption (verification hub). No nominee tip. No invented costs. |

### Slide table

| Slide | On-screen text | Purpose |
|---|---|---|
| 1 | The questions I get asked most — from every buyer looking at Kuta. | Hook · invite swipe |
| 2 | Can I legally buy a property in Kuta? | Question 1 |
| 3 | Nominee? Or a PT PMA — and how do I set one up? | Question 2–3 |
| 4 | What are the ongoing costs after purchase? | Question 4 · CTA |

### Per-slide delivery

**Slide 1**
1. Visual intent: PROOF this is a buyer Q hub — calm Habitat still or clean graphic. Not a sales render dump.
2. Best still: Garden/Vibe exterior still (Indigo pick). Matt-to-camera = FILM — use graphic if unshot.
3. Avoid: busy data charts on cover; villa-count scarcity; stay/Airbnb framing.
4. Text hierarchy: big hook one line · tiny support · ~75% visual.

**Slide 2**
1. Visual intent: legal clarity, not fear.
2. Best still: simple legal icon graphic or quiet site still.
3. Avoid: fake certificate screenshots; nominee “how-to”.
4. Text hierarchy: question big · no answer on slide (answer in caption).

**Slide 3**
1. Visual intent: contrast bad path vs proper company path — words only if no approved diagram.
2. Best still: clean two-column graphic (Nominee ✕ · PT PMA ✓) — copy only, no fake paperwork.
3. Avoid: telling people to use a nominee.
4. Text hierarchy: two short labels · negative space.

**Slide 4**
1. Visual intent: costs are real and discussable — no invented % or fee sheet.
2. Best still: soft lifestyle still + CTA bar.
3. Avoid: ROI/occ numbers; prospectus collage (0 in catalogue = FILM).
4. Text hierarchy: question · small CTA.

Stories: poll “Which question first?” · tour CTA on a site still (Matt update video = FILM).

---

## Wed 16 Sep · Post 2 · MATCH

| Field | Value |
|---|---|
| Day + date | Wednesday 16 Sep 2026 |
| Post # + title | Post 2 — Best Places to Eat Within 10 Minutes of Habitat |
| Format | CAROUSEL · 3 SLIDES |
| Pillar | Lifestyle / Local |
| CTA | Tour · or the prospectus |
| Hashtags | #HabitatVibe #KutaLombok #LombokFood #KutaVilla |
| Caption angle | Neighbourhood proof for foreign buyers. Named places only if already public/confirmed — else “nearby”. No invented reviews. No stay CTA. |

### Slide table

| Slide | On-screen text | Purpose |
|---|---|---|
| 1 | Within 10 minutes of Habitat. | Cover · location |
| 2 | Eat well without leaving the area. | Food proof |
| 3 | See the site. Ask the real questions. | Soft CTA |

### Per-slide delivery

**Slide 1**
1. Visual intent: LOCATION — Habitat ↔ nearby food, not a menu close-up alone.
2. Best still: map graphic or road/neighbourhood still (Indigo).
3. Avoid: inventing restaurant names; Bali food stock.
4. Text hierarchy: one line cover · lots of space.

**Slide 2**
1. Visual intent: appetite + place — plated food in Kuta/Lombok context.
2. Best still: confirmed local food still or generic “nearby table” if names unconfirmed.
3. Avoid: fake 5-star review cards; OTA guest stay framing.
4. Text hierarchy: short line · food leads.

**Slide 3**
1. Visual intent: back to investment brand — site, not a booking engine.
2. Best still: Habitat exterior.
3. Avoid: stay booking CTAs; villa counts.
4. Text hierarchy: CTA small under still.

Stories: “Live music or chill dinner?” poll · prospectus link only if asset exists (else drop).

---

## Fri 18 Sep · Post 3 · FILM

| Field | Value |
|---|---|
| Day + date | Friday 18 Sep 2026 |
| Post # + title | Post 3 — Reasons Not to Buy a Habitat Villa? |
| Format | REEL (or copy carousel if flipped MATCH) |
| Pillar | Informational / Contrarian |
| CTA | DM `LOMBOK` |
| Gate | FILM — host or full graphic set required. Do not schedule until shot or flipped to copy-only MATCH. |

### Slide / beat table (for when filmed)

| Beat | On-screen text | Purpose |
|---|---|---|
| 1 | Reasons not to buy a Habitat villa. | Hook |
| 2 | If you need overnight Airbnb income this month — this isn’t it. | Honest filter |
| 3 | If you won’t walk a build — wait. | Proof culture |
| 4 | If you want a nominee shortcut — we won’t do that. | Legal filter |
| 5 | Still here? Talk to us. | CTA |

### Per-beat delivery
1. Visual intent: honesty filter for serious buyers — not scare spam.
2. Footage sequence: host face OR kinetic text on site B-roll (Indigo). No fake owner.
3. Avoid: villa counts; ROI; “don’t miss out”; stay CTAs.
4. Text hierarchy: one line per beat · big type · quiet B-roll.

Stories: BTS only if shoot exists · poll “Which reason hit?”

---

## Mon 21 Sep · Post 4 · FILM

| Field | Value |
|---|---|
| Day + date | Monday 21 Sep 2026 |
| Post # + title | Post 4 — If I Was Buying My First Villa in Lombok… |
| Format | REEL · Matt sit-down |
| Pillar | Personality / Trust |
| CTA | Book a site tour · DM |
| Gate | FILM — Matt talking-head 0. Lav walkaround cannot carry this. Do not schedule until sit-down exists. |

### Beat table

| Beat | On-screen text | Purpose |
|---|---|---|
| 1 | If I was buying my first villa in Lombok… | Hook |
| 2 | I’d walk the build before I wired money. | Lesson |
| 3 | I’d use a proper company structure — not a nominee. | Legal |
| 4 | I’d ask who answers the phone after handover. | Ops |
| 5 | That’s the bar at Habitat. | Closer |

### Per-beat delivery
1. Visual intent: founder proof — face + site, not stock.
2. Footage: face-to-camera 20–30s + cutaways steel/garden (MATCH B-roll only).
3. Avoid: ROI promises; occupancy claims; comedy interrupt (not this post).
4. Text hierarchy: question overlays only · Matt voice leads.

Stories: quote card from biggest lesson · tour CTA on site still.

---

## Wed 23 Sep · Post 5 · FILM

| Field | Value |
|---|---|
| Day + date | Wednesday 23 Sep 2026 |
| Post # + title | Post 5 — Owner testimonial (TBC) |
| Format | REEL |
| Pillar | Proof |
| CTA | DM `LOMBOK` |
| Gate | FILM — do not invent a name. Do not schedule until a real owner clip exists. |

### Beat table (placeholder)

| Beat | On-screen text | Purpose |
|---|---|---|
| 1 | [Owner first name only — after approval] | Identity |
| 2 | Why they bought | Story |
| 3 | What surprised them | Proof |
| 4 | Would they do it again? | Trust |
| 5 | Ask an owner your question — DM | CTA |

### Per-beat delivery
1. Visual intent: real owner voice — Proof not promise.
2. Footage: approved owner interview only.
3. Avoid: fabricated quotes; occupancy/ROI overlays; guest/OTA stay reviews.
4. Text hierarchy: short subtitles · face primary.

Stories: “What would you ask an owner?” · prospectus only if real asset.

---

## Fri 25 Sep · Post 6 · FILM

| Field | Value |
|---|---|
| Day + date | Friday 25 Sep 2026 |
| Post # + title | Post 6 — A Walk Around Site with Matt (outtakes) |
| Format | REEL |
| Pillar | Project Spotlight / Personality |
| CTA | DM / book a tour |
| Gate | FILM — hosted walk. 15 Jun lav ≠ this. Comedy interrupt stays FILM. Do not schedule until shot. |

### Beat table

| Beat | On-screen text | Purpose |
|---|---|---|
| 1 | Walk around Vibe with Matt. | Hook |
| 2 | Named work this week | Progress |
| 3 | Outtake / laugh | Human |
| 4 | Still early. Still walkable. | Honest closer |
| 5 | Come walk it. | CTA |

### Per-beat delivery
1. Visual intent: founder on site, progress you can see — not a polished tour ad.
2. Footage sequence: Matt walk-and-talk → steel/foundations cutaways → one outtake → wide leave.
3. Avoid: villa counts; finished-amenity fakes; stay CTAs.
4. Text hierarchy: light captions · voice leads.

Stories: extra bloopers only if shoot exists · sunrise/sunset poll OK.

---

## Honesty / Scout
- No Ready-to-post from Muse. FILM never schedules.
- Indigo rematch before Velvet READY/PARTIAL.
- Answers to legal/cost questions live in captions from approved materials only.
