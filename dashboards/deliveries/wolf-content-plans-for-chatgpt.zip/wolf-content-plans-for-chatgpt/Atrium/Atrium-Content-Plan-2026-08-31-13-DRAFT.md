---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/02-Atrium/Content/Atrium-Content-Plan-2026-08-31-13-DRAFT.md
mtime: 2026-08-17 20:54:47 WITA
brand: Atrium
title: Atrium Content Plan 2026 08 31 13 DRAFT
date_range: 2026-08-31 to 2026-09-13
exported: 2026-09-14
---

# Atrium fortnight draft · 31 Aug–13 Sep 2026 · honesty pass

Status: DRAFT. MATCH can sit in the vault. FILM does not schedule. Nothing posted.
Handle: @atrium_lombok
Do not use: sold %, opening date, occupancy %, Booking.com, yield %, finished lagoon/25m/bathhouse/pool cinema, Type C 33sqm, “sleep here from September”

## Mon 31 MATCH
Now + named work (15–17 Jun exteriors / scaffolding / rooftop frame). No fake then/now. Catalogue newest 18 Jun — last-fortnight pair does not exist.
1 current exterior "this week"
2 scaffolding or rooftop frame "named work"
3 more now "still going in"
4 CTA "download the prospectus"
FILM locked-off pair if they want spot-the-difference.

## Tue 1 FILM
Sales & guest-experience team. No hospitality video in library. Construction crew is not this post. Do not schedule until shot.

## Wed 2 FILM
Client DM + Matt/Amanda on site. No talking-head. Do not schedule until shot.

## Thu 3 MATCH
Lombok / site exteriors. No invented tourism %, land values, or occupancy.
1 site or lombok still "why lombok"
2 named place "kuta · mandalika is on the map"
3 CTA "download the prospectus"
No sold %. No yield.

## Fri 4 MATCH
Type C render only (LS_VERTICAL_APARTMENT_C.mp4). Real C25 not tagged. $125k resale TBC — off-slide.
1 render "you’ve seen this render"
2 render second angle "type C · studio"
3 furnished room we have (not tagged C25) "a finished room on site"
4 CTA "download the prospectus"

## Sat 5 MATCH
Different logo. Not Sat 22 Atrium_logo.png / Final_Logo.PNG. Not Sat 29 Atrium_arch / letter / white if those were used. Leftover lockup only. No finished-pool reflection.

## Sun 6 MATCH
Stories only. Leftover light/courtyard/pathway.
CTA "book a tour"

## Mon 7 MATCH
Now + named work. No fake milestone if it is not in frame. Catalogue newest 18 Jun.
1 current exterior "this week"
2 named work "what changed"
3 CTA "book accommodation" / site
FILM if a real Sep milestone is shot.

## Tue 8 MATCH
Site engineers / supervisor + crew.
1 engineer "the ones who sign it off"
2 crew "same site"
3 faces "the people behind atrium"
4 CTA "download the prospectus"

## Wed 9 MATCH
17 Jun furnished room + shower/kitchenette/balcony. 500m Kuta is site copy, not footage.
1 furnished room "500m from kuta beach"
2 shower/kitchenette "book the room · not the story"
3 balcony "book accommodation" / site
No rate card. No Booking.com. No September date. No occupancy.

## Thu 10 FILM
Owner / guest in their own words. No testimonial in library. Do not schedule until shot.

## Fri 11 MATCH
Balcony / rooftop we have. Do not fake ocean-at-night or finished pool.
1 balcony or rooftop "this is the hour"
2 furnished corner or rain shower "what you can already walk"
3 CTA "download the prospectus"
Coffee-in-hand = FILM or drop that beat.

## Sat 12 MATCH
Different logo. Not a finished-pool reflection. Unfinished pool only if copy stays honest.

## Sun 13 MATCH
Stories only. Leftover light/courtyard/pathway. Thank you.
CTA "book a tour"
