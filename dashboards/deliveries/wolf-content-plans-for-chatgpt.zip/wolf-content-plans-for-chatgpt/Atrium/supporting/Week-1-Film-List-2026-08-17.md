---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/02-Atrium/Content/Week-1-Film-List-2026-08-17.md
mtime: 2026-08-17 17:53:05 WITA
brand: Atrium
title: Week 1 Film List 2026 08 17
date_range: n/a
exported: 2026-09-14
---

# Film list · 17 Aug 2026 · from Library match

Nothing posts. Catalogue newest capture: 18 Jun 2026.

## Habitat — must film
- Two One Minute with Matt sit-downs (mistake / location). Walkaround cannot carry them.
- Meisya still 0.
- Merdeka crew story, or drop it.

## Atrium — must film
- Merdeka / Merah Putih on site, or drop those stories (17 Aug is today).
- Nespresso + cooktop
- In-room safe
- Labeled Type C real room (render exists; real room not tagged)

## Do not fake
- Finished lagoon, 25m lap, bathhouse, pool cinema
- TV is mount only
- Flatlay 0

## Can use now
- Atrium: construction, people, 17 Jun furnished rooms, rain shower, rooftop/balcony, logos, brochure PDF
- Habitat: Vibe steel-frame 15–18 Jun, Garden trades, Masashi Garden tour 8 Dec 2025
