---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Atrium-Lombok/Atrium-Brand.md
mtime: 2026-06-23 19:45:38 WITA
brand: Atrium
title: Atrium Brand
date_range: n/a
exported: 2026-09-14
---

# Atrium Lombok — Complete Brand Knowledge

**Operator:** AMG (Atrium Management Group)  
**Brand Type:** Luxury aparthotel + Surga Spa (wellness vertical)  
**Location:** Kuta Beach, Lombok (500m from beach)  
**Status:** COMPLETE (text_style: logo-only, full palette configured)  
**Last Updated:** 2026-06-22 (from brand-config.json)

## Related Files

- [[Atlas-Overview|01-Wolf-Command/Atlas-System/SOPs/Atlas-Overview.md]]
- [[Surga-Brand|01-Wolf-Command/Brands/Surga-Spa/Surga-Brand.md]]
- [[Theme-Bank-Master|01-Wolf-Command/Atlas-System/Theme-Bank/Theme-Bank-Master.md]]
- [[Style-Profiles|01-Wolf-Command/Team/Content-Team/Style-Profiles.md]]


---

## ESSENCE & VOICE

**Brand Essence:** Luxurious, peaceful, aspirational, tropical modern  
**Voice Descriptors:**
- luxurious
- peaceful
- aspirational
- tropical modern
- luxurious & aspirational
- five-star + managed-investment confidence
- beachside (500m Kuta Beach)
- Gilda-serif elegance

**Tone:** Sophisticated, refined, confident (not desperate). Positioned for both tourists and managed-investment audience.

---

## COLOR PALETTE

| Role | Hex | Name | Usage |
|------|-----|------|-------|
| Sand Gold | `#D5B688` | Warm gold | Primary accent, luxe warmth |
| Sage | `#7EAEA9` | Muted green | Secondary accent, tropical calm |
| Steel Blue | `#547D8F` | Professional blue | Tertiary, trustworthy |
| Deep Teal | `#335D68` | Dark teal | Text depth, contrast |
| Stone Grey | `#636466` | Neutral grey | Supporting, professional |
| [Dark] | `#1E293B` | Slate | Bottom bar, deep backgrounds |

**Bottom Bar:** `#1E293B` (dark slate) at 0.7 opacity  
**Label Color:** `#D4AF37` (gold text on dark bar — premium feel)

---

## TYPOGRAPHY

**Primary Typeface:** Gilda Display (elegant serif)  
**Secondary:** Work Sans (modern sans)  
**Font Package:** `fonts/` (Gilda Display + Work Sans installed)

| Role | Family | Weight | File | Usage |
|------|--------|--------|------|-------|
| Display (graphics) | Gilda Display | Regular | GildaDisplay-Regular.ttf | Headlines, branding |
| Sans (graphics) | Work Sans | Medium | WorkSans-Medium.ttf | Body, secondary text |
| (Captions use palette heuristic — see text_style below) | — | — | — | — |

**Text Style (Logo-Only Config):**
- Primary logo asset: `logos/Atrium_logo.png` (color) + `logos/Atrium_logo_white.png` (white)
- Secondary assets: Arch icon + Letter wordmark (for accent use)
- No explicit role→color mapping; colors derive via palette luminance heuristic
- Logo placement: Top-left, 20% frame width, 5% margin

---

## LOGOS

**Asset Root:** `/Volumes/01-Media-Library/Brand-Assets/AMG/Atrium`

| Logo | Path | Usage |
|------|------|-------|
| Primary Logo | `logos/Atrium_logo.png` | Main lockup (color) |
| Primary Logo (white) | `logos/Atrium_logo_white.png` | On dark backgrounds |
| Arch Icon | `logos/Atrium_arch.png` | Favicon, secondary mark |
| Arch Icon (white) | `logos/Atrium_arch_white.png` | White variant |
| Letter Wordmark | `logos/Atrium_letter.png` | Typography accent |
| Letter Wordmark (white) | `logos/Atrium_letter_white.png` | White variant |

---

## VISUAL LANGUAGE

- Tropical modern architecture (clean lines, natural materials)
- Sunset + golden hour photography
- Interior lifestyle (guest experiences, shared spaces)
- Managed investment confidence (property stats, guest testimonials)
- Five-star service moments (staff, guest interaction)
- Serene, uncluttered spaces
- Beachside positioning (ocean, tropical setting)

---

## CONTENT PILLARS

1. **Five-Star Moments** — Guest arrival, room reveal, amenities, sunset, service
2. **Wellness & Spa (Surga Spa)** — Spa serenity, treatment showcase, rejuvenation
3. **Investor Confidence** — Booking data, guest reviews, managed-investment thesis
4. **Beach & Sunset** — Golden hour, relaxation, tropical escape
5. **Property Performance** — Numbers, testimonials, ROI positioning

---

## VIDEO GRADING & MUSIC

**Reel Engine Slug:** `atrium`  
**Grading:** Warm luxury grade with enhanced blues for tropical feel
- Master curve: `0/0 0.08/0.06 0.45/0.48 0.75/0.78 0.95/0.97 1/1`
- Red channel: Warm lift
- Blue channel: Cool shadows
- Saturation: +14%, Contrast: +5%

**Music:** `epic-documentary-bg.mp3` (aspirational, confident)  
**Pacing:** Medium (stately, not rushed)

**Reel Engine Codes (for auto-matching):**
- atrium
- amg (Atrium Management Group)
- atrium management

---

## NAS & ASSET LOCATION

**NAS Path:** `/Volumes/01-Media-Library/Brand-Assets/AMG/Atrium`

**Folder Structure:**
```
Atrium/
├── fonts/ (Gilda Display + Work Sans)
├── logos/
│   ├── Atrium_logo.png
│   ├── Atrium_logo_white.png
│   ├── Atrium_arch.png
│   ├── Atrium_arch_white.png
│   ├── Atrium_letter.png
│   └── Atrium_letter_white.png
├── raws/ (hotel footage)
├── finished/ (edited videos, photos)
└── graphics/ (promotional assets)
```

---

## AUDIENCE & POSITIONING

**Primary Audience:**
- Luxury travelers (5-star hotel seekers, Instagram-savvy)
- Managed investment community (financial professionals, ROI-focused)
- Lifestyle & wellness audience (spa/retreat seekers)

**Messaging Balance:**
- 40% luxury lifestyle (aspirational)
- 30% operational excellence (five-star service)
- 20% investment opportunity (managed-investment confidence)
- 10% wellness positioning (Surga Spa)

---

## APPROVAL & TEAM

**Operations Lead:** AMG (TBD — hotel staff)  
**Content Lead (Reviewer):** Amanda (GGV GM)  
**Editor:** Haikal (GGV)  
**Director:** Mr Wolf

**Style Profile:** See `/01-Wolf-Command/Team/Content-Team/Style-Profiles.md` (Amanda)

---

## BRAND CONFIG STATUS

**Text Style:** COMPLETE (logo-only config, full palette synced from Canva Brand Kit 2026-06-02)  
**Logo Paths:** COMPLETE (6 logo variants)  
**Fonts:** COMPLETE (Gilda Display + Work Sans installed)  
**Intro/Outro:** Standard (default outro enabled)  
**Reel Engine:** MIGRATED (grading + music verified 2026-05-25)

---

**Vault Source:** brand-config.json (2026-06-22)  
**Next Update:** Weekly sync via vault-sync.sh
