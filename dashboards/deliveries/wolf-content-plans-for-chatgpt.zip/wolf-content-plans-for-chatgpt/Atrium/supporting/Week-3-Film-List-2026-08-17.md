---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/02-Atrium/Content/Week-3-Film-List-2026-08-17.md
mtime: 2026-08-17 21:00:11 WITA
brand: Atrium
title: Week 3 Film List 2026 08 17
date_range: n/a
exported: 2026-09-14
---

# Atrium film list · fortnight 31 Aug–13 Sep · 17 Aug 2026
Nothing posts. Catalogue newest capture: 18 Jun 2026.
Source: MATCH-31-Aug-13-Sep-2026.md + Atrium-Content-Plan-2026-08-31-13-DRAFT.md (combined fortnight; split 31–06 / 07–13 gone). DRAFT files not touched.

## Must film
- Tue 1 Sep — sales & guest-experience team. No hospitality / front-desk / concierge video. Construction crew is not this post.
- Wed 2 Sep — client DM + Matt and Amanda on Atrium site. Amanda-alone site (Amanda C16, Oct 2025) exists; Matt+Amanda together 0. No talking-head.
- Thu 3 Sep slide 2 — named place “kuta · mandalika is on the map”. Site exteriors are not Mandalika. May 15 drone and RAW_9 coastal not labelled Kuta. Use a graphic/map or shoot it.
- Thu 10 Sep — owner / guest in their own words. Atrium-Interview-* are job interviews, not testimonials.
- Fri 11 Sep beat only — coffee-in-hand on balcony/rooftop, or drop that beat. Post stays MATCH without it.

## Do not fake
- Finished lagoon, 25m, bathhouse, pool cinema
- Habitat pools as Atrium swim
- TV as a working set (mount only)
- Type C 33sqm / labelled real C25
- Then/now pair (newest still 18 Jun)

## Can use now
- 15–17 Jun exteriors, scaffolding RAW_7 weekly, rooftop RAW_11
- 17 Jun furnished room / shower / kitchen / balcony
- One Type C render: LS_VERTICAL_APARTMENT_C.mp4 (no second C render)
- Engineer IMG_4274 · office IMG_1888 · supervisor IMG_6030 · briefing IMG_2357
- Leftover logos: Atrium_logo_white.png (Sat 5), Final_Logo_1.PNG (Sat 12)
- Leftover light / courtyard / pathway for Sun 6 and Sun 13
