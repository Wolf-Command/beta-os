---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/02-Atrium/Atrium-Strategy.md
mtime: 2026-06-23 19:45:38 WITA
brand: Atrium
title: Atrium Strategy
date_range: n/a
exported: 2026-09-14
---

---

## Related Files

- [[Atrium-Brand|01-Wolf-Command/Brands/Atrium-Lombok/Atrium-Brand.md]]
- [[Uma-Blu-Brand|01-Wolf-Command/Brands/Uma-Blu-Cafe/Uma-Blu-Brand.md]]
- [[Theme-Bank-Master|01-Wolf-Command/Atlas-System/Theme-Bank/Theme-Bank-Master.md]]
- [[Style-Profiles|01-Wolf-Command/Team/Content-Team/Style-Profiles.md]]

brand: Atrium
display: Atrium
company: AMG
type: brand-strategy
source: Brand-Assets/AMG/Atrium/content-strategy/Atrium-Investment-Brochure.pdf (NAS; owner 2026-06-21)
fonts: { display: "Gilda Display", body: "Work Sans" }
note: a8 is an investor/sales brochure (units, ROI, amenities) — gives positioning + facts, not a voice-pillar guide like Tropik/Selo. Treat the lifestyle voice as best-effort until a content-pillar guide is provided.
---

# Atrium — Positioning & Strategy

**One line:** "Luxury Living in Indonesia's Fastest Growing Beachside Market." Atrium Lombok —
apartments, hotel suites & dual-key units, 500m from Kuta Beach, Lombok. Aspirational luxury that
doubles as a managed investment.

## Voice
Luxurious · aspirational · sophisticated · tropical-modern · investment-confident (calm authority,
not hard sell). Pairs five-star lifestyle with "we look after your investment so you can sleep at
night."

## Positioning anchors (factual, from the brochure)
- 500m from Kuta Beach, Lombok; opening mid-2026; ~75% sold.
- Unit types: studios → premium 2-bed dual-key (20–143 sqm); fully furnished, "move-in &
  investment-ready."
- Investment: 3-yr 10% guaranteed option vs variable pooled; "buy now, pay half later."
- Amenities: wine cellar, luxury bathhouse (sauna, magnesium pool, hammam, sensory tank), 3 pools,
  gym, kids club, day spa, co-working, private boat club, underground parking, 24/7 concierge.
- On-site F&B (cross-brand): **Blu Zone Restaurant**, **Uma Blu** coffee, rooftop cocktails.

## Two audiences
1. **Lifestyle** (hotel/residence guests) — elegant Gilda-serif "escape the everyday" register;
   suites, pools, bathhouse, dining, sunset.
2. **Investment** (buyers) — confident, factual: returns, dual-key flexibility, managed
   occupancy. Keep it confidence-led, not a spreadsheet.

## CTAs / contacts
"Book a viewing" / "Book your site tour" · atriumlombok.com · sales@atriumlombok.com ·
+62 811 390 07500 · @atrium_lombok.

## Template implications
Gilda Display serif headline (title case), Work Sans subhead/CTA, sand-gold/sage palette, generous
negative space — already in the Atrium story template (best-effort; no finished static reference
yet — tune when a content-pillar/finished example is provided).
