---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/02-Atrium/Content/Atrium-Content-Plan-2026-09-14-27-DRAFT.md
mtime: 2026-09-05 19:04:07 WITA
brand: Atrium
title: Atrium Content Plan 2026 09 14 27 DRAFT
date_range: 2026-09-14 to 2026-09-27
exported: 2026-09-14
---

# Atrium fortnight draft · 14–27 Sep 2026 · honesty pass

Status: DRAFT. Source HTML atrium-2026-09-14-27. Follows 31 Aug–13 Sep. Nothing posted.
Handle: @atrium_lombok
Do not use: sold %, opening date, occupancy %, Booking.com URL, yield invent, finished lagoon/25m/bathhouse/pool cinema, Type C 33sqm, “sleep here from September”
Catalogue newest capture still 18 Jun unless Library rematches. FILM does not schedule.
Metricool note (17 Aug–5 Sep, real): carousels win — 24 Aug 120 int / 1,751 reach; 2 Sep 115 / 1,349. No invented numbers beyond that.

## Mon 14 MATCH
Weekly Update #5. Now + named work. No fake then/now.
1 current exterior "this week"
2 named work "still going in"
3 CTA "download the prospectus"
FILM locked-off pair if they want spot-the-difference.

## Tue 15 FILM
People of Atrium — Legal & Compliance. Notary / compliance faces. Construction crew is not this post. Do not schedule until shot.

## Wed 16 MATCH
What we’d tell you first — warnings. Copy carousel. Foreign buyer.
1 cover "before you buy in indonesia"
2 "not on price alone"
3 "legal structure first"
4 "local leasehold without the right licence"
5 CTA "download the prospectus"
No invented ROI. No guaranteed return.

## Thu 17 MATCH
Myth-buster: can foreigners own. Copy / graphic. PT PMA = company owns, not direct title.
1 hook "can foreigners own here?"
2 "not freehold · a company can"
3 CTA "book a tour"
No nominee advice as a tip. FILM talking-head if they want Matt on camera.

## Fri 18 MATCH
Ten minutes from Atrium. Site / Kuta stills. No invented amenity list.
1 nearby "ten minutes"
2 kuta still "kuta, lombok"
3 CTA "book accommodation" / site

## Sat 19 MATCH
Logo. Leftover lockup. No finished-pool reflection.

## Sun 20 MATCH
Stories only. Leftover light/courtyard. CTA "book a tour"

## Mon 21 MATCH
Weekly Update #6. Now + named work. Same honesty as Mon 14.

## Tue 22 FILM
People — Finance & Investment Advisors. New faces. Do not schedule until shot.

## Wed 23 FILM
If this was my first time investing in Lombok — personal reel. Talking-head 0. Do not schedule until shot.

## Thu 24 MATCH
Render to Reality — Unit A12. Render only if tagged; real A12 not assumed.
1 render "you’ve seen this render"
2 real room we have (not labelled A12 unless tagged) "a finished room on site"
3 CTA "download the prospectus"
Price off-slide until Matthew confirms.

## Fri 25 MATCH
Slow afternoon. Unfinished pool only if copy stays honest. Rooftop/balcony we have.
1 balcony or rooftop "this is the hour"
2 CTA "download the prospectus"
Do not fake finished pool light.

## Sat 26 MATCH
Different logo. Not Sat 19 lockup.

## Sun 27 MATCH
Stories only. Thank you. CTA "book a tour"
