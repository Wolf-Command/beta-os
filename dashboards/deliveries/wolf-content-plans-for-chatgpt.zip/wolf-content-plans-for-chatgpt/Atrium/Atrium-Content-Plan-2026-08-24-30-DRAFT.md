---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/02-Atrium/Content/Atrium-Content-Plan-2026-08-24-30-DRAFT.md
mtime: 2026-08-17 17:57:00 WITA
brand: Atrium
title: Atrium Content Plan 2026 08 24 30 DRAFT
date_range: 2026-08-24 to 2026-08-30
exported: 2026-09-14
---

# Atrium week 2 draft · 24–30 Aug 2026 · honesty pass

Status: DRAFT. MATCH can sit in the vault. FILM does not schedule. Nothing posted.

## Mon 24 MATCH
Now + named work (15–17 Jun exteriors / scaffolding / rooftop frame). No fake then/now.
1 current exterior "this week"
2 scaffolding or rooftop frame "named work"
3 more now "still going in"
4 CTA "book accommodation" / site

## Tue 25 MATCH
Construction supervisor/engineer + crew. Hospitality video = FILM, not this post.
1 supervisor "the ones who sign it off"
2 engineer or crew "same site"
3 faces "the people behind atrium"
4 CTA "download the prospectus"

## Wed 26 MATCH
17 Jun furnished room + shower/kitchenette/balcony. 500m Kuta is site copy, not footage.
1 furnished room "500m from kuta beach"
2 shower/kitchenette "book the room · not the story"
3 balcony "book accommodation" / site
No September date.

## Thu 27 FILM
Faces in Atrium water. Empty/unfinished pool only. No Habitat pools. Do not schedule until shot. If unshot: no swim post.

## Fri 28 FILM
Night. No Atrium night footage. Do not schedule until shot.

## Sat 29 MATCH
Different logo: Atrium_arch / letter / white. Not Sat 22 Atrium_logo.png / Final_Logo.PNG.

## Sun 30 MATCH
Stories only. Leftover light/courtyard/pathway.
