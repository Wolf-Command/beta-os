---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Uma-Blu/Content/Uma-Blu-Content-Plan-2026-09-14-27-DRAFT.md
mtime: 2026-09-05 19:04:07 WITA
brand: Uma-Blu
title: Uma Blu Content Plan 2026 09 14 27 DRAFT
date_range: 2026-09-14 to 2026-09-27
exported: 2026-09-14
---

# Uma Blu fortnight draft · 14–27 Sep 2026 · honesty pass

Status: DRAFT. Source HTML uma-blu-2026-09-14-27. Local. Bahasa-first. Captions Kuta, Lombok. Nothing posted.
Halal = dapur/makanan only. Alcohol OK. Bar-licence post ON HOLD.
WA +62 811-2899-9008. Metricool: do not invent. Last hard post window thin (2 feed posts 17 Aug–5 Sep).

## Mon 14 MATCH
Things we’ll never judge you for. Food + space stills. Bahasa overlays OK.
1 cover "di uma blu, kami nggak judge"
2 plate "brunch malam? boleh"
3 CTA "WA book · kuta, lombok"

## Wed 16 FILM
Treat yourself reel. Need appetite sequence. Food still alone is partial. Do not schedule until shot.

## Fri 18 MATCH
The kind of morning we could get used to. Coffee / light / table.
1 morning "pagi di kuta"
2 coffee "kopi dulu"
3 CTA "WA book · kuta, lombok"

## Mon 21 FILM
Staff favourite orders part 3. Faces + names. Do not schedule until shot.

## Wed 23 MATCH
What your order says about you, part 2. Drink stills only. No invented SKU.
1 cover "order kamu bilang apa · part 2"
2 drink still "pilih kamu"
3 CTA "komen + tag · kuta, lombok"
New-item slides = FILM until the kitchen names the drop.

## Fri 25 FILM
A morning at Uma Blu — open to close. Day-in-the-life. Do not schedule until the sequence is shot.
