---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Uma-Blu/Content/Uma-Blu-Content-Plan-2026-08-31-13-DRAFT.md
mtime: 2026-08-17 20:54:47 WITA
brand: Uma-Blu
title: Uma Blu Content Plan 2026 08 31 13 DRAFT
date_range: 2026-08-31 to 2026-09-13
exported: 2026-09-14
---

# Uma Blu fortnight draft · 31 Aug–13 Sep 2026 · honesty pass

Status: DRAFT. Local. Bahasa-first. Captions Kuta, Lombok. Nothing posted.
Halal = dapur/makanan only. Alcohol OK. Bar-licence post ON HOLD.

## Mon 31 MATCH
Kinda Chic carousel. Food + space stills. Staff-to-camera and Ms Tia = FILM slides — drop those two if unshot.
1 cover "kinda chic to…"
2 brunch plate "…makan brunch malam-malam"
3 french toast "…makanan yang cantik"
4 CTA "kuta, lombok · WA book"

## Wed 2 FILM
ASMR “watch your order come to life.” Do not schedule until the pour sequence is shot.

## Fri 4 MATCH
What your order says. Drink stills only.
1 cover "order kamu bilang apa"
2 cold brew "main character"
3 CTA "komen + tag · kuta, lombok"

## Mon 7 FILM
Staff picks part 2. Faces + names. Do not schedule until shot.

## Wed 9 FILM
Pesto toastie cheese pull. Sandwich still is not the reel. Do not schedule until the pull exists.

## Fri 11 FILM
New item joining the table. LEARN does not name the SKU. Do not invent it. Do not schedule until the drop is real.
