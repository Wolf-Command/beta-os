---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Uma-Blu/Content/Uma-Blu-Content-Plan-2026-08-24-30-DRAFT.md
mtime: 2026-08-17 20:51:58 WITA
brand: Uma-Blu
title: Uma Blu Content Plan 2026 08 24 30 DRAFT
date_range: 2026-08-24 to 2026-08-30
exported: 2026-09-14
---

# Uma Blu week 2 draft · 24–30 Aug 2026 · honesty pass

Status: DRAFT. Local. Bahasa-first. Captions Kuta, Lombok. Nothing posted.
Halal = dapur/makanan only. Alcohol OK. Bar-licence post ON HOLD.

## Mon 24 MATCH
Kinda chic tease (leads 31 Aug). Food + space. No talking-head.
1 flatlay "kinda chic to…"
2 plate "brunch malam juga boleh"
3 CTA "save · WA book · kuta, lombok"

## Wed 26 FILM
ASMR drink build (ice / pour / overflow). Do not schedule until the sequence is shot.

## Fri 28 MATCH
Order-personality stills. Drinks we already serve. No new SKU.
1 cold brew "main character"
2 oreo / kopi nut "pilih kamu"
3 CTA "tag temenmu · kuta, lombok"
