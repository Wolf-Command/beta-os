---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Uma-Blu/Content/Week-3-Film-List-2026-08-17.md
mtime: 2026-08-17 21:00:11 WITA
brand: Uma-Blu
title: Week 3 Film List 2026 08 17
date_range: n/a
exported: 2026-09-14
---

# Uma Blu film list · 17 Aug 2026
Do not schedule. DRAFT plans not overwritten. F&B only. Captions Kuta, Lombok. WA +6281128999008.

Covers FILM items across 17–23, 24–30, and the combined 31–13 fortnight draft.

## Wed 26 Aug — ASMR drink build
Need: ice / pour / overflow sequence.
Nearby, not this post: MAH00283.MP4 ice scoop (20 May 2026); MAH00392.MP4 pour with ice (21 May 2026). Catalogue ASMR = 0.

## Wed 2 Sep — ASMR “watch your order come to life”
Need: pour sequence as a reel. Latte-pour stills/video exist (MAH00456.MP4, 21 May 2026). Not the sequence.

## Mon 7 Sep — Staff picks part 2
Need: faces + names, staff naming a real menu item.
Nearby, not this post: nindy_Floor_Staff_Alfi / Arya / Awan / Iza / Kartini / Lulu.mov (28 May 2026) — poses / count-ins. Do not use BZG/Staff HR files.

## Wed 9 Sep — Pesto toastie cheese pull
Need: the pull action. Sandwich still is not the reel.
Nearby, not this post: IMG_2107.HEIC pesto/melted-cheese still (24 Mar 2026); IMG_2066.MOV plated grilled cheese (24 Mar 2026).

## Fri 11 Sep — Unnamed new drop
Need: the real new SKU, named by LEARN or the kitchen. Do not invent it. `umablu_new_menu_*` stills exist and must not be labelled as a new drop.
