---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Uma-Blu/Uma-Blu-Brand.md
mtime: 2026-07-21 17:20:16 WITA
brand: Uma-Blu
title: Uma Blu Brand
date_range: n/a
exported: 2026-09-14
---

# Uma Blu — Brand Profile
**Entity:** PT Blu Zone Group (BZG)
**Owner:** Matthew Goss
**Venues:** Uma Blu Café, Beach Club, Pool Bar, Underground, Rooftop

## Brand Voice
Vibrant, social, tropical luxury. Lombok's premium beach lifestyle destination.
Daytime-coastal-bright, breezy, ocean-adjacent. Coffee & brunch; "brewing happiness
daily." Warm, made with care; playful but cozy. IG @umablulombok.

## Colour Palette
_Confirmed from official branding guide (brand-config.json / Uma-Blu-branding-guide.jpg)._

| Hex | Name | Role |
|---|---|---|
| `#2E4776` | Dusk Blue | primary / bottom bar |
| `#741828` | Burgundy | |
| `#D8913D` | Butterscotch | |
| `#3C2A20` | Bistre | |
| `#DCECE9` | Azure Mist | |
| `#FEFCFB` | White | label text |
| `#242124` | Raisin Black | depth |

**Bottom bar:** `#2E4776` at 70% opacity; label text `#FEFCFB`.

## Typography
- **Headline / display:** Forum
- **Body / labels:** Hanken Grotesk
- **Accent:** Professor — script word-mark only, do NOT substitute (never for burned auto-captions).

## Related Files

- [[Uma-Blu-Strategy|01-Wolf-Command/Brands/Uma-Blu-Cafe/Uma-Blu-Strategy.md]]
- [[Agent-BZG|03-BZG/Agent-BZG.md]]
- [[Atlas-Overview|01-Wolf-Command/Atlas-System/SOPs/Atlas-Overview.md]]
- [[Theme-Bank-Master|01-Wolf-Command/Atlas-System/Theme-Bank/Theme-Bank-Master.md]]
- [[Style-Profiles|01-Wolf-Command/Team/Content-Team/Style-Profiles.md]]


## Content Priorities
- Beach Club atmosphere
- Signature cocktails and food
- Sunset moments
- Event coverage

## Assets
- 71 recipes compiled → Uma_Blu_Recipes_Complete.pdf
- Recipe library available for content and menu planning

## Notes
- Primary content brand in Atlas pipeline
- Haikal is lead videographer on-site
