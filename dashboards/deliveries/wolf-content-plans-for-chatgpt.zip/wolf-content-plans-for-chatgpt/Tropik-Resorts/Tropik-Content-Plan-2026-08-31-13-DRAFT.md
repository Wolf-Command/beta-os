---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Tropik-Resorts/Content/Tropik-Content-Plan-2026-08-31-13-DRAFT.md
mtime: 2026-08-17 20:54:47 WITA
brand: Tropik-Resorts
title: Tropik Content Plan 2026 08 31 13 DRAFT
date_range: 2026-08-31 to 2026-09-13
exported: 2026-09-14
---

# Tropik fortnight draft · 31 Aug–13 Sep 2026 · honesty pass

Status: DRAFT. No 31 Aug–13 Sep source plan. Same spine. No new promo invented.
Stays not ownership. @tropiklombok. No room rates. CTA tropiklombok.com · INSTAGRAM.

## Mon 31 MATCH
Slow living again. Pool / belanak / sunset. New cut of the same feeling.
1 pool "no plans"
2 sunset "selong belanak"
3 CTA "tropiklombok.com · INSTAGRAM"

## Wed 2 MATCH
Restaurant / dinner feeling. Do not extend 2-for-1 into September as a fact.
1 table "dinner here"
2 CTA "tropiklombok.com · INSTAGRAM"

## Fri 4 FILM
BBQ Saturday invitation. Standing BBQ from LEARN. FILM if no fire/grill.

## Mon 7 MATCH
Design / villa light / garden texture. Space shown. No rates.
1 light "the room"
2 garden "the hour"
3 CTA "tropiklombok.com · INSTAGRAM"

## Wed 9 FILM
Padel follow. Do not say “broke ground this week.” Do not schedule unless a real Sep clip exists.

## Fri 11 MATCH
Lifestyle closer. Surf / sunset / buffalo.
1 lifestyle "this"
2 CTA "tropiklombok.com · INSTAGRAM"
BBQ stories Saturday. Live fire = FILM if no grill.
