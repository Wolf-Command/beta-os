---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Tropik-Resorts/Content/Tropik-Content-Plan-2026-08-24-30-DRAFT.md
mtime: 2026-08-17 20:51:58 WITA
brand: Tropik-Resorts
title: Tropik Content Plan 2026 08 24 30 DRAFT
date_range: 2026-08-24 to 2026-08-30
exported: 2026-09-14
---

# Tropik week 2 draft · 24–30 Aug 2026 · honesty pass

Status: DRAFT. Stays not ownership. @tropiklombok. Nothing posted.
No room rates. CTA tropiklombok.com · code INSTAGRAM. No new promo invented.

## Mon 24 FILM
Room to be together. Family breakfast / kids in pool. Empty villa is not this post. Do not schedule until family footage exists.

## Wed 26 FILM
Padel ground-break. Do not claim “we broke ground this week” without the clip. Do not schedule until shot.

## Fri 28 MATCH
Chasing this lifestyle. Coast / surf / buffalo / sunset.
1 road "chase this"
2 belanak "this is the lifestyle"
3 CTA "tropiklombok.com · INSTAGRAM"
BBQ Saturday in stories. Live fire = FILM if no grill.
