---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Tropik-Resorts/Tropik-Strategy.md
mtime: 2026-06-23 19:45:38 WITA
brand: Tropik-Resorts
title: Tropik Strategy
date_range: n/a
exported: 2026-09-14
---

---

## Related Files

- [[Tropik-Brand|01-Wolf-Command/Brands/Tropik-Resorts/Tropik-Brand.md]]
- [[Atlas-Overview|01-Wolf-Command/Atlas-System/SOPs/Atlas-Overview.md]]
- [[Theme-Bank-Master|01-Wolf-Command/Atlas-System/Theme-Bank/Theme-Bank-Master.md]]
- [[Style-Profiles|01-Wolf-Command/Team/Content-Team/Style-Profiles.md]]
- [[Habitat-Strategy|01-Wolf-Command/Brands/Habitat-Villas/Habitat-Strategy.md]]

brand: Tropik
display: Tropik
company: GGV
type: brand-strategy
source: Brand-Assets/GGV/Tropik/content-strategy/Tropik-{Lifestyle,Experience,Design}-Pillar.pdf (NAS; owner 2026-06-21)
fonts: { display: "Aesthet Nova", body: "Noto Sans" }
---

# Tropik — Content Strategy

**One line:** Tropik markets *memories and a way of living*, not rooms. The destination and the
feeling are the hero; the villa is the backdrop.

## Voice
Calm · warm · natural · observational. Show, don't explain — let viewers reach conclusions.
Titles read like **observations, not advertisements**. Anti-promotional: no clickbait, no
real-estate language, no influencer hype.

## Three content pillars
1. **South Lombok Lifestyle** — sell the *destination* before the stay. Beaches (Selong Belanak,
   Mawun, Mawi, Seger, Tanjung Aan), nature, surf culture, local culture, food & local gems,
   exploration ("places within 15/30/60 min"), slow living. Goal: "I need to visit South Lombok" →
   Tropik becomes the natural base. NOT villa tours/amenities (those are Design).
2. **Experience** — sell the *feeling* of staying: slow mornings, shared meals, family &
   togetherness, easy access to experiences, small details/hospitality. Emotion first, visuals
   support. "I want that experience," not "I want that villa."
3. **Design** — architecture/atmosphere/spatial storytelling: space & flow, natural light,
   materials & texture (timber, stone, woven, local craft), indoor-outdoor living, intentional
   design. Emotion before specs. "I want to spend time there," not "that villa has 2 bedrooms."

## Headlines (observation + emotion, never feature + benefit)
"Some Things Move Slower Here" · "Worth The Drive" · "Nothing Feels Accidental Here" · "The Luxury
Of Space" · "Where Light Does Most Of The Work" · "Room To Be Together" · "A Different Way To
Experience Lombok".

## Captions
Add meaning, don't repeat the visual. Open with a feeling → human moment → how design/place
enables it → soft close. Connect to an emotion (freedom, curiosity, slowing down, connection).

## CTA = invitation, not sales pitch
"Book your stay directly at tropiklombok.com" · "Discover South Lombok from Tropik". Avoid
"Book now before it's too late", limited-offer, hard sell.

## Visual style
Natural light, breathing room, longer shots, human scale, framed views, indoor-outdoor
transitions. Avoid fast edits, aggressive transitions, over-polished tourism content.

## Template implications (graphic-templates.json)
Lowercase Aesthet Nova headlines in the "some spaces just feel better" register; muted
linen/gold; clean editorial type (no decorative shape). Already reflected in the Tropik story
template — this doc is the source of truth for its tone.
