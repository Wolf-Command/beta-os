---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Tropik-Resorts/Tropik-Brand.md
mtime: 2026-06-23 19:45:38 WITA
brand: Tropik-Resorts
title: Tropik Brand
date_range: n/a
exported: 2026-09-14
---

# Tropik Resorts Lombok — Complete Brand Knowledge

**Client:** GGV (Goss Group Ventures)  
**Brand Type:** Destination resort / eco-resort, family-focused  
**Location:** South Lombok (Selong area)  
**Status:** COMPLETE (text_style with logo override, full palette)  
**Last Updated:** 2026-06-22 (from brand-config.json)

## Related Files

- [[Tropik-Strategy|01-Wolf-Command/Brands/Tropik-Resorts/Tropik-Strategy.md]]
- [[GGV-Brand|01-Wolf-Command/Brands/GGV/GGV-Brand.md]]
- [[Theme-Bank-Master|01-Wolf-Command/Atlas-System/Theme-Bank/Theme-Bank-Master.md]]
- [[Style-Profiles|01-Wolf-Command/Team/Content-Team/Style-Profiles.md]]


---

## ESSENCE & VOICE

**Brand Essence:** Natural tropical, family-focused, relaxed yet vibrant  
**Voice Descriptors:**
- natural tropical
- family-focused
- relaxed yet vibrant
- calm & observational
- destination-first (sell South Lombok)
- show don't tell
- anti-promotional — titles read as observations
- slow living

**Tone:** Observational, educational, anti-hype. "South Lombok's hidden stories" framing. Documentary-style, not sales brochure.

---

## COLOR PALETTE

| Role | Hex | Name | Usage |
|------|-----|------|-------|
| Hunter Green | `#33684F` | Primary green | Bottom bar, primary accent |
| Muted Olive | `#A0B57A` | Soft olive | Secondary, nature accent |
| Light Gold | `#EAD88B` | Warm gold | Tertiary, warmth |
| Glaucous | `#7389AE` | Muted blue | Sky tones, calm |
| Soft Linen | `#F3EFE6` | Off-white | Background, breathing room |
| Graphite | `#272A26` | Dark charcoal | Depth, shadows |

**Bottom Bar:** `#33684F` (hunter green) at 0.7 opacity  
**Label Color:** `#F3EFE6` (soft linen text — light on dark green)

---

## TYPOGRAPHY

**Primary Typeface:** Aesthet Nova (modern, clean, approachable)  
**Secondary:** Noto Sans (universal fallback)  
**Font Package:** `fonts/` (Aesthet Nova .otf + Noto Sans .ttf installed)

| Role | Family | Weight | File | Usage |
|------|--------|--------|------|-------|
| Display (graphics) | Aesthet Nova | Medium | fonnts.com-Aesthet-Nova-Medium.otf | Headlines, branding |
| Sans (graphics) | Noto Sans | Regular | NotoSans-Regular.ttf | Body, secondary text |
| (Captions use palette heuristic) | — | — | — | — |

**Text Style (Logo-Only Config):**
- Primary logo asset: `logos/Tropik_Resort_logo.png` (color) + `logos/Tropik_Resort_logo_white.png` (white)
- Source masters (high-res print): `logos/Tropik_Resort_logo_source.png` (for print)
- No explicit role→color mapping; colors derive via palette luminance heuristic
- Logo placement: Top-left, 20% frame width, 5% margin

---

## LOGOS

**Asset Root:** `/Volumes/01-Media-Library/Brand-Assets/GGV/Tropik`

| Logo | Path | Resolution | Usage |
|------|------|-----------|-------|
| Logo (color) | `logos/Tropik_Resort_logo.png` | ~1000px (working) | Video, web |
| Logo (white) | `logos/Tropik_Resort_logo_white.png` | ~1000px | Dark backgrounds |
| Logo (source color) | `logos/Tropik_Resort_logo_source.png` | High-res | Print, archival |
| Logo (source white) | `logos/Tropik_Resort_logo_white_source.png` | High-res | Print white |

---

## VISUAL LANGUAGE

- Natural landscapes (no heavy filters, documentary-feel)
- Family moments + group dynamics
- Relaxation + slow living aesthetic
- Authentic local culture + environment
- Minimal over-styling (photography feels earned, not staged)
- Activity + wellness-focused (yoga, walks, exploration)
- Morning light, golden hour, real moments

---

## CONTENT PILLARS

1. **South Lombok as Destination** — Geography, culture, natural beauty first
2. **Family-Friendly Experiences** — Intergenerational appeal, group moments
3. **Wellness + Slow Living** — Yoga, meditation, nature connection
4. **Local Culture + Community** — Respect, authenticity, partnership
5. **Sustainable Tourism** — Eco-friendly positioning

---

## VIDEO GRADING & MUSIC

**Reel Engine Slug:** `tropic_at_selong`  
**Grading:** Vibrant yet natural, enhanced saturation for tropical colors
- Master curve: `0/0 0.06/0.05 0.45/0.47 0.8/0.84 1/1`
- Red channel: Natural warmth
- Green channel: Lifted for foliage
- Blue channel: Enhanced for sky
- Saturation: +20%, Contrast: +6%

**Music:** `cinematic-clear-skies.mp3` (uplifting, contemporary)  
**Pacing:** Medium-slow (allows for documentary moments)

**Reel Engine Codes (for auto-matching):**
- tropik
- tropic
- tropic at selong
- tropic_at_selong

---

## CONTENT PERFORMANCE

**Best Platforms:**
- TikTok (younger family demographic, short-form)
- Instagram Reels (60+ sec destination guides)
- YouTube (long-form family content, 5+ min)
- Pinterest (travel planning, lifestyle pins)

**Best Times:**
- Friday–Sunday (travel planning happens weekends)
- Morning (aspiration + planning)
- Evening (dreaming mode)

**Highest Engagement Topics:**
- Destination guides (6-8% ER)
- Family moments (7-9% ER)
- Local culture deep-dives (8-10% ER)
- Wellness content (6-8% ER)

---

## NAS & ASSET LOCATION

**NAS Path:** `/Volumes/01-Media-Library/Brand-Assets/GGV/Tropik`

**Folder Structure:**
```
Tropik/
├── fonts/ (Aesthet Nova + Noto Sans)
├── logos/
│   ├── Tropik_Resort_logo.png (working)
│   ├── Tropik_Resort_logo_white.png
│   ├── Tropik_Resort_logo_source.png (print master)
│   └── Tropik_Resort_logo_white_source.png
├── raws/ (footage)
├── finished/ (videos, photos)
└── graphics/ (promotional assets)
```

---

## APPROVAL & TEAM

**Content Lead (Reviewer):** Nindy (GGV)  
**Editor:** Haikal (GGV)  
**Director:** Mr Wolf, Amanda (GGV GM)

**Style Profile:** See `/01-Wolf-Command/Team/Content-Team/Style-Profiles.md` (Nindy, Haikal)

---

## BRAND CONFIG STATUS

**Text Style:** COMPLETE (logo-only, full palette configured)  
**Logo Paths:** COMPLETE (working + source variants)  
**Fonts:** COMPLETE (Aesthet Nova + Noto Sans installed)  
**Intro/Outro:** Standard (default outro enabled)  
**Reel Engine:** MIGRATED (grading + music verified 2026-05-25)

---

**Vault Source:** brand-config.json (2026-06-22)  
**Next Update:** Weekly sync via vault-sync.sh
