---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Tropik-Resorts/Content/Week-3-Film-List-2026-08-17.md
mtime: 2026-08-17 21:00:11 WITA
brand: Tropik-Resorts
title: Week 3 Film List 2026 08 17
date_range: n/a
exported: 2026-09-14
---

# Tropik film list · 17 Aug 2026
Do not schedule. @tropiklombok. Stays not ownership. No rates. INSTAGRAM in CTA only. Do not use Habitat/Atrium rooms.

Covers FILM items across 17–23, 24–30, and the combined 31–13 fortnight draft, after the honesty flips.

## Still FILM
### Wed 26 Aug — Padel ground-break
Padel = 0 in catalogue (path / subject / things / location). Do not claim “we broke ground this week.”

### Wed 9 Sep — Padel follow
Same gap. Do not schedule unless a real Sep clip exists.

## Flipped off this list (real clips exist)
- Wed 19 Aug 2-for-1 food → MATCH (5 May 2026 restaurant food / two drinks).
- Fri 21 Aug BBQ → MATCH (grill / fire-pit exist; not a live Saturday event shoot).
- Mon 24 Aug family → MATCH (Villa Mia 2021 family-by-pool; 2022 family dining).
- Fri 4 Sep BBQ → MATCH (combined 31–13 draft said FILM if no fire/grill; grill exists).
