---
source: /Users/wolfterminal/WolfCommandSystem/WolfCommand/01-Wolf-Command/Brands/Tropik-Resorts/Content/Tropik-Content-Plan-2026-09-14-27-DRAFT.md
mtime: 2026-09-05 19:04:07 WITA
brand: Tropik-Resorts
title: Tropik Content Plan 2026 09 14 27 DRAFT
date_range: 2026-09-14 to 2026-09-27
exported: 2026-09-14
---

# Tropik fortnight draft · 14–27 Sep 2026 · honesty pass

Status: DRAFT. Source HTML tropik-2026-09-14-27. Stays not ownership. @tropiklombok. Nothing posted.
LEARN HTML used Sun/Tue/Fri — locked cadence is Mon/Wed/Fri. Remapped below.
No room rates. CTA tropiklombok.com · code INSTAGRAM. Save-% off the slide.
2-for-1 only as in-house dinner mention in stories if still live — do not invent a new promo.
BBQ Saturday in stories only if standing. FILM live fire if no grill.

## Mon 14 MATCH
This is what they came for. Guest/UGC only if a real tagged guest exists — else lifestyle belanak/pool.
1 pool or belanak "this is what they came for"
2 sunset "selong belanak"
3 CTA "tropiklombok.com · INSTAGRAM"
Named guest reel = FILM until permissioned UGC exists.

## Wed 16 MATCH
Best days rarely need a plan. Pool / coconut / belanak.
1 pool "no plans"
2 beach "a wave when you feel like it"
3 CTA "tropiklombok.com · INSTAGRAM"

## Fri 18 FILM
They know where to go — staff story. Faces naming a local spot. Do not schedule until shot.

## Mon 21 MATCH
Some mornings don’t need much. Soft light / coffee / garden.
1 morning "some mornings"
2 coffee or garden "reset"
3 CTA "tropiklombok.com · INSTAGRAM"

## Wed 23 MATCH
Where to eat when you stay at Tropik. Named partners only if confirmed — else generic nearby + onsite restaurant.
1 cover "where to eat"
2 restaurant still "near tropik"
3 CTA "tropiklombok.com · INSTAGRAM"
No rates. No invented partner list.

## Fri 25 MATCH
My problem is I want every day to look like this. Surf / buffalo / sunset montage.
1 lifestyle "this"
2 CTA "tropiklombok.com · INSTAGRAM"
